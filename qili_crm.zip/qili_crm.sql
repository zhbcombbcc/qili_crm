/*
Navicat MySQL Data Transfer

Source Server         : locallhost
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : qili_crm

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2018-10-27 17:47:48
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for qili_bulletin
-- ----------------------------
DROP TABLE IF EXISTS `qili_bulletin`;
CREATE TABLE `qili_bulletin` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '文章id',
  `title` varchar(155) NOT NULL COMMENT '文章标题',
  `content` text NOT NULL COMMENT '文章内容',
  `time` int(11) NOT NULL COMMENT '发布时间',
  `user_id` int(255) DEFAULT NULL COMMENT '发布人',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qili_bulletin
-- ----------------------------
INSERT INTO `qili_bulletin` VALUES ('53', '放入放放入放', '<p>455445</p>', '2018', '1');
INSERT INTO `qili_bulletin` VALUES ('54', '上班制度调整通知', '上班制度调整通知', '2018', '1');
INSERT INTO `qili_bulletin` VALUES ('55', '春节放假通知', '春节放假通知', '0', '1');
INSERT INTO `qili_bulletin` VALUES ('58', 'd', 'ddd', '1540180865', '1');

-- ----------------------------
-- Table structure for qili_customer
-- ----------------------------
DROP TABLE IF EXISTS `qili_customer`;
CREATE TABLE `qili_customer` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `source` tinyint(255) DEFAULT '1' COMMENT '来源 1：猪八戒网、2：威客网、3：老客户、4：其他',
  `third_order_id` varchar(11) DEFAULT NULL COMMENT '项目第三方平台订单号',
  `customer` varchar(255) DEFAULT NULL COMMENT '联系人',
  `phone` varchar(255) DEFAULT NULL COMMENT '电话',
  `project_name` varchar(11) DEFAULT NULL COMMENT '项目名称',
  `wechat` varchar(255) DEFAULT NULL COMMENT '微信号',
  `qq` varchar(255) DEFAULT NULL COMMENT 'QQ号',
  `budget` decimal(11,2) unsigned NOT NULL COMMENT '预算',
  `demand` varchar(255) DEFAULT NULL COMMENT '需求',
  `demand_detail` text NOT NULL COMMENT '详细需求',
  `demand_file_path` varchar(255) DEFAULT NULL COMMENT '上传的需求文件',
  `remarks` text COMMENT '备注',
  `remarks_file_path` varchar(255) DEFAULT NULL COMMENT '上传的备注文件',
  `status` tinyint(4) DEFAULT '1' COMMENT '客户状态 1：可跟、2：潜在、3：意向、4：成交、5：退款、6：OUT',
  `add_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `one_time` int(11) DEFAULT NULL COMMENT '第一次跟进时间',
  `one_enclosure_path` varchar(255) DEFAULT NULL COMMENT '第一次跟进附件',
  `one_remarks` text COMMENT '第一次跟进备注',
  `two_time` int(11) DEFAULT NULL COMMENT '第二次跟进时间',
  `two_enclosure_path` varchar(255) DEFAULT NULL COMMENT '第二次跟进附件',
  `two_remarks` text COMMENT '第二次跟进备注',
  `three_time` int(11) DEFAULT NULL COMMENT '第三次跟进时间',
  `three_enclosure_path` varchar(255) DEFAULT NULL COMMENT '第三次跟进附件',
  `three_remarks` text COMMENT '第三次跟进备注',
  `offer` decimal(11,2) DEFAULT NULL COMMENT '报价',
  `time_limit` varchar(255) DEFAULT NULL COMMENT '工期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qili_customer
-- ----------------------------
INSERT INTO `qili_customer` VALUES ('1', '1', '5656565', '系统', '15315571023', '测试', '1', '1', '20000.00', '1', '1', '1', '1', null, '1', '1', '1538323200', '1', '1', '1538409600', '20181027/bcc54de9150b5975a32b231ceea9556c.docx', '2', '1539792000', '20181027/ac4a210cdb57ee0459f6e7e22a3ad660.docx', '3', '18000.00', '20天');
INSERT INTO `qili_customer` VALUES ('25', '2', '3232', '889', '889', '测试1', '6865', '455445', '455.00', '3232', '5445', '20181026/f91f7c8828881531738fc28117b58604.docx', '544554', '20181026/cad864770716af720528fe0d5d13d2f7.docx', '2', '1540543758', null, null, null, null, null, null, null, null, null, null, null);

-- ----------------------------
-- Table structure for qili_document
-- ----------------------------
DROP TABLE IF EXISTS `qili_document`;
CREATE TABLE `qili_document` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `doc_path` varchar(255) DEFAULT NULL COMMENT '文档路径',
  `upload_time` int(11) DEFAULT NULL COMMENT '上传时间',
  `down_count` int(255) DEFAULT '0' COMMENT '下载次数',
  `user_id` int(11) DEFAULT NULL COMMENT '上传者ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qili_document
-- ----------------------------
INSERT INTO `qili_document` VALUES ('20', '测试问题.docx', '20181023/3d0b0dd26f3db3db1c5795af7aaaa8d7.docx', '1540259808', '2', '1');
INSERT INTO `qili_document` VALUES ('21', 'test.xlsx', '20181023/59546c47e5f5f4b276716ac614dfc9e4.xlsx', '1540261941', '2', '1');

-- ----------------------------
-- Table structure for qili_node
-- ----------------------------
DROP TABLE IF EXISTS `qili_node`;
CREATE TABLE `qili_node` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `node_name` varchar(155) NOT NULL DEFAULT '' COMMENT '节点名称',
  `control_name` varchar(155) NOT NULL DEFAULT '' COMMENT '控制器名',
  `action_name` varchar(155) NOT NULL COMMENT '方法名',
  `is_menu` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否是菜单项 1不是 2是',
  `type_id` int(11) NOT NULL COMMENT '父级节点id',
  `style` varchar(155) DEFAULT '' COMMENT '菜单样式',
  `show_type` tinyint(1) NOT NULL DEFAULT '2' COMMENT '1、前台显示 2、后台显示',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of qili_node
-- ----------------------------
INSERT INTO `qili_node` VALUES ('1', '用户管理', '#', '#', '2', '0', 'fa fa-users', '2');
INSERT INTO `qili_node` VALUES ('2', '管理员管理', 'user', 'index', '2', '1', '', '2');
INSERT INTO `qili_node` VALUES ('3', '添加管理员', 'user', 'useradd', '1', '2', '', '2');
INSERT INTO `qili_node` VALUES ('4', '编辑管理员', 'user', 'useredit', '1', '2', '', '2');
INSERT INTO `qili_node` VALUES ('5', '删除管理员', 'user', 'userdel', '1', '2', '', '2');
INSERT INTO `qili_node` VALUES ('6', '角色管理', 'role', 'index', '2', '1', '', '2');
INSERT INTO `qili_node` VALUES ('7', '添加角色', 'role', 'roleadd', '1', '6', '', '2');
INSERT INTO `qili_node` VALUES ('8', '编辑角色', 'role', 'roleedit', '1', '6', '', '2');
INSERT INTO `qili_node` VALUES ('9', '删除角色', 'role', 'roledel', '1', '6', '', '2');
INSERT INTO `qili_node` VALUES ('10', '分配权限', 'role', 'giveaccess', '1', '6', '', '2');
INSERT INTO `qili_node` VALUES ('11', '系统管理', '#', '#', '2', '0', 'fa fa-desktop', '2');
INSERT INTO `qili_node` VALUES ('12', '数据备份/还原', 'data', 'index', '2', '11', '', '2');
INSERT INTO `qili_node` VALUES ('13', '备份数据', 'data', 'importdata', '1', '12', '', '2');
INSERT INTO `qili_node` VALUES ('14', '还原数据', 'data', 'backdata', '1', '12', '', '2');
INSERT INTO `qili_node` VALUES ('15', '节点管理', 'node', 'index', '2', '1', '', '2');
INSERT INTO `qili_node` VALUES ('16', '添加节点', 'node', 'nodeadd', '1', '15', '', '2');
INSERT INTO `qili_node` VALUES ('17', '编辑节点', 'node', 'nodeedit', '1', '15', '', '2');
INSERT INTO `qili_node` VALUES ('18', '删除节点', 'node', 'nodedel', '1', '15', '', '2');
INSERT INTO `qili_node` VALUES ('25', '个人中心', '#', '#', '1', '0', '', '2');
INSERT INTO `qili_node` VALUES ('26', '编辑信息', 'profile', 'index', '1', '25', '', '2');
INSERT INTO `qili_node` VALUES ('27', '编辑头像', 'profile', 'headedit', '1', '25', '', '2');
INSERT INTO `qili_node` VALUES ('28', '上传头像', 'profile', 'uploadheade', '1', '25', '', '2');
INSERT INTO `qili_node` VALUES ('29', '客户管理', '#', '#', '2', '0', 'fa fa-pie-chart', '2');
INSERT INTO `qili_node` VALUES ('30', '添加客户', 'customer', 'add', '1', '29', '', '2');
INSERT INTO `qili_node` VALUES ('31', '客户列表', 'customer', 'index', '2', '29', '', '2');
INSERT INTO `qili_node` VALUES ('39', '团队管理', '#', '#', '2', '0', 'fa fa-sitemap', '2');
INSERT INTO `qili_node` VALUES ('40', '济南', 'customer', 'all_user', '2', '39', '', '2');
INSERT INTO `qili_node` VALUES ('41', '财务管理', '#', '#', '2', '0', 'fa fa-bar-chart-o', '2');
INSERT INTO `qili_node` VALUES ('42', '项目回款', 'order', 'index', '2', '41', '', '2');
INSERT INTO `qili_node` VALUES ('43', '项目续费', 'order', 'renew', '2', '41', '', '2');
INSERT INTO `qili_node` VALUES ('44', '系统公告', '#', '#', '2', '0', 'fa fa-volume-up', '2');
INSERT INTO `qili_node` VALUES ('45', '总结管理', '#', '#', '2', '0', 'fa fa-book', '2');
INSERT INTO `qili_node` VALUES ('46', '北京', 'customer', 'beijing', '2', '39', '', '2');
INSERT INTO `qili_node` VALUES ('47', '系统公告', 'bulletin', 'index', '2', '44', '', '2');
INSERT INTO `qili_node` VALUES ('48', '我的总结', 'summary', 'my', '2', '45', '', '2');
INSERT INTO `qili_node` VALUES ('49', '团队总结', 'summary', 'team', '2', '45', '', '2');
INSERT INTO `qili_node` VALUES ('50', '写总结', 'summary', 'add', '1', '45', '', '2');
INSERT INTO `qili_node` VALUES ('51', '删除总结', 'summary', 'del', '1', '45', '', '2');
INSERT INTO `qili_node` VALUES ('52', '修改总结', 'summary', 'edit', '1', '45', '', '2');
INSERT INTO `qili_node` VALUES ('53', '查看总结', 'summary', 'see', '1', '45', '', '2');
INSERT INTO `qili_node` VALUES ('54', '文档下载', 'document', 'index', '2', '44', '', '2');
INSERT INTO `qili_node` VALUES ('55', '添加系统公告', 'bulletin', 'add', '1', '44', '', '2');
INSERT INTO `qili_node` VALUES ('56', '编辑系统公告', 'bulletin', 'edit', '1', '44', '', '2');
INSERT INTO `qili_node` VALUES ('57', '删除系统公告', 'bulletin', 'del', '1', '44', '', '2');
INSERT INTO `qili_node` VALUES ('58', '查看系统公告', 'bulletin', 'see', '1', '44', '', '2');
INSERT INTO `qili_node` VALUES ('59', '下载文档', 'document', 'download', '1', '44', '', '2');
INSERT INTO `qili_node` VALUES ('60', '删除文档', 'document', 'del', '1', '44', '', '2');
INSERT INTO `qili_node` VALUES ('61', '上传文档', 'document', 'upload', '1', '44', '', '2');
INSERT INTO `qili_node` VALUES ('62', '添加文档', 'document', 'add', '1', '44', '', '2');
INSERT INTO `qili_node` VALUES ('63', '添加项目', 'order', 'add', '1', '41', '', '2');
INSERT INTO `qili_node` VALUES ('64', '编辑', 'order', 'edit', '1', '41', '', '2');
INSERT INTO `qili_node` VALUES ('65', '删除', 'order', 'del', '1', '41', '', '2');
INSERT INTO `qili_node` VALUES ('66', '设置续费', 'order', 'set_renew', '1', '41', '', '2');
INSERT INTO `qili_node` VALUES ('67', '上传文件', 'customer', 'upload', '1', '29', '', '2');
INSERT INTO `qili_node` VALUES ('68', '编辑客户', 'customer', 'edit', '1', '29', '', '2');
INSERT INTO `qili_node` VALUES ('69', '删除客户', 'customer', 'del', '1', '29', '', '2');
INSERT INTO `qili_node` VALUES ('70', '状态跟进', 'customer', 'track', '1', '29', '', '2');
INSERT INTO `qili_node` VALUES ('71', '成交填写', 'customer', 'deal', '1', '29', '', '2');

-- ----------------------------
-- Table structure for qili_order
-- ----------------------------
DROP TABLE IF EXISTS `qili_order`;
CREATE TABLE `qili_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) DEFAULT NULL COMMENT '客户ID',
  `third_order_id` int(11) DEFAULT NULL COMMENT '项目第三方平台订单号',
  `total_amount` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '总金额',
  `batch` varchar(255) DEFAULT NULL COMMENT '分批次',
  `telephone` varchar(255) DEFAULT NULL COMMENT '座机电话',
  `project_name` varchar(255) DEFAULT NULL COMMENT '项目名称',
  `project_cate_id` int(11) DEFAULT NULL COMMENT '项目分类  1：网站、2：APP、3：公众号、4：小程序、5：其他',
  `time_limit` varchar(11) DEFAULT NULL COMMENT '工期',
  `start_time` int(11) DEFAULT NULL COMMENT '开始时间',
  `end_time` int(11) DEFAULT NULL COMMENT '结束时间',
  `reminding_time` int(10) DEFAULT NULL COMMENT '提醒时间',
  `contract_path` varchar(255) DEFAULT NULL COMMENT '合同',
  `require_doc_path` varchar(255) DEFAULT NULL COMMENT '需求文档',
  `remarks` varchar(255) DEFAULT NULL COMMENT '备注',
  `is_return_money` tinyint(255) DEFAULT '0' COMMENT '是否回款  1：是、2：否',
  `is_gift_server` tinyint(255) DEFAULT '0' COMMENT '是否赠送服务器 1：是 、2：否',
  `is_gift_space` tinyint(255) DEFAULT '0' COMMENT '是否赠送空间 1：是 、2：否',
  `pay_amount` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '需付费金额',
  `is_gift_domain` tinyint(255) DEFAULT '0' COMMENT '是否赠送域名  1：是、 2：否',
  `is_renew` tinyint(255) DEFAULT '0' COMMENT '是否续费 1：是、2：否',
  `first_batch_backamount` decimal(10,0) unsigned DEFAULT '0' COMMENT '第一批回款金额',
  `first_batch_backtime` int(10) DEFAULT '0' COMMENT '第一批回款时间',
  `second_batch_backamount` decimal(10,0) unsigned DEFAULT '0' COMMENT '第二批回款金额',
  `second_batch_backtime` int(10) DEFAULT '0' COMMENT '第二批回款时间',
  `third_batch_backamount` decimal(10,0) unsigned DEFAULT '0' COMMENT '第三批回款金额',
  `third_batch_backtime` int(10) DEFAULT '0' COMMENT '第三批回款时间',
  `add_time` int(11) DEFAULT NULL COMMENT '添加时间',
  `is_refund` tinyint(255) DEFAULT NULL COMMENT '是否退款 1：是、  2：否',
  `refund_time` int(11) DEFAULT NULL COMMENT '退款时间',
  `refund_amount` decimal(10,0) DEFAULT NULL COMMENT '退款金额',
  `phone` varchar(255) DEFAULT NULL COMMENT '电话',
  `customer_evaluation` varchar(255) DEFAULT NULL COMMENT '客户评价',
  `status` tinyint(255) DEFAULT '2' COMMENT '进度状态 1：已完成、 2：未回款',
  `renew_amount` decimal(11,2) DEFAULT '0.00' COMMENT '续费金额',
  `length_of_time` tinyint(4) DEFAULT NULL COMMENT '续费时长 1：一年、2：二年、3：三年',
  `renew_time` int(11) DEFAULT NULL COMMENT '续费时间',
  `expiry_time` int(11) DEFAULT NULL COMMENT '到期时间',
  `renew_reminding` tinyint(4) DEFAULT NULL COMMENT '提醒时间  1：提前一周、2：提前二周、3：提前三周、4：提前一月、5：提前三月',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qili_order
-- ----------------------------
INSERT INTO `qili_order` VALUES ('1', '1', '2147483647', '0.00', '3', '80808080', '百世如意', '1', '1月', '1539705600', '1538888888', '1539705600', null, null, '666', '1', '1', '1', '0.00', '1', '1', '1000', '1539792000', '2000', '1540569600', '3000', '1539273600', '1540361234', '1', '1540396800', '3000', '15315571023', '/upload/20181024/9e24ceb46ce3c791f900d521f422387e.png', '1', '1000.00', '1', '1538323200', '1569859200', '4');

-- ----------------------------
-- Table structure for qili_order_copy
-- ----------------------------
DROP TABLE IF EXISTS `qili_order_copy`;
CREATE TABLE `qili_order_copy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer` varchar(11) DEFAULT NULL COMMENT '客户',
  `order_id` int(11) DEFAULT NULL COMMENT '订单号',
  `total_amount` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '总金额',
  `batch` varchar(255) DEFAULT NULL COMMENT '分批次',
  `telephone` varchar(255) DEFAULT NULL COMMENT '座机电话',
  `project_name` varchar(255) DEFAULT NULL COMMENT '项目名称',
  `project_cate_id` int(11) DEFAULT NULL COMMENT '项目分类',
  `time_limit` varchar(0) DEFAULT NULL COMMENT '工期',
  `start_time` int(11) DEFAULT NULL COMMENT '开始时间',
  `end_time` int(11) DEFAULT NULL COMMENT '结束时间',
  `reminding_time` int(10) DEFAULT NULL COMMENT '提醒时间',
  `contract` varchar(255) DEFAULT NULL COMMENT '合同',
  `requirements_document` varchar(255) DEFAULT NULL COMMENT '需求文档',
  `remarks` varchar(255) DEFAULT NULL COMMENT '备注',
  `is_return_money` tinyint(255) DEFAULT '0' COMMENT '是否回款 0：否、1：是',
  `is_gift_server` tinyint(255) DEFAULT '0' COMMENT '是否赠送服务器 0：否、1：是',
  `is_gift_space` tinyint(255) DEFAULT '0' COMMENT '是否赠送空间 0：否、1：是',
  `pay_amount` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '需付费金额',
  `is_gift_domain` tinyint(255) DEFAULT '0' COMMENT '是否赠送域名  0：否、1：是',
  `is_renew` tinyint(255) DEFAULT '0' COMMENT '是否续费 0：否、1：是',
  `first_batch_backamount` decimal(10,0) unsigned DEFAULT '0' COMMENT '第一批回款金额',
  `first_batch_backtime` int(10) DEFAULT '0' COMMENT '第一批回款时间',
  `second_batch_backamount` decimal(10,0) unsigned DEFAULT '0' COMMENT '第二批回款金额',
  `second_batch_backtime` int(10) DEFAULT '0' COMMENT '第二批回款时间',
  `third_batch_backamount` decimal(10,0) unsigned DEFAULT '0' COMMENT '第三批回款金额',
  `third_batch_backtime` int(10) DEFAULT '0' COMMENT '第三批回款时间',
  `already_return_money` decimal(10,0) unsigned DEFAULT '0' COMMENT '已回款',
  `add_time` int(11) DEFAULT NULL COMMENT '添加时间',
  `remainder` decimal(10,0) DEFAULT '0' COMMENT '剩余款',
  `is_refund` tinyint(255) DEFAULT NULL COMMENT '是否退款 1：是、  2：否',
  `refund_time` int(11) DEFAULT NULL COMMENT '退款时间',
  `refund_amount` decimal(10,0) DEFAULT NULL COMMENT '退款金额',
  `phone` varchar(255) DEFAULT NULL COMMENT '电话',
  `customer_evaluation` varchar(255) DEFAULT NULL COMMENT '客户评价',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qili_order_copy
-- ----------------------------
INSERT INTO `qili_order_copy` VALUES ('6', '张', '2147483647', '10000.00', '3', null, '百世如意', null, null, null, null, '1539705600', null, null, null, '0', '0', '0', '0.00', '0', '0', '1000', '1539792000', '2000', '1540569600', '3000', '1539273600', '0', '1540361234', '0', '2', '1540396800', '3000', '15315571023', '/upload/20181024/9e24ceb46ce3c791f900d521f422387e.png');

-- ----------------------------
-- Table structure for qili_renew_copy
-- ----------------------------
DROP TABLE IF EXISTS `qili_renew_copy`;
CREATE TABLE `qili_renew_copy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL COMMENT '订单号',
  `renew_amount` decimal(11,2) DEFAULT '0.00' COMMENT '续费金额',
  `length_of_time` tinyint(4) DEFAULT NULL COMMENT '续费时长',
  `renew_time` int(11) DEFAULT NULL COMMENT '续费时间',
  `expiry_time` int(11) DEFAULT NULL,
  `add_time` int(4) DEFAULT NULL COMMENT '添加时间',
  `renew_reminding` tinyint(4) DEFAULT NULL COMMENT '提醒时间  1：提前一周、2：提前二周、3：提前三周、4：提前一月、5：提前三月',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qili_renew_copy
-- ----------------------------
INSERT INTO `qili_renew_copy` VALUES ('1', '6', '1.00', '1', '1', '1', '1', '1');

-- ----------------------------
-- Table structure for qili_role
-- ----------------------------
DROP TABLE IF EXISTS `qili_role`;
CREATE TABLE `qili_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `role_name` varchar(155) NOT NULL COMMENT '角色名称',
  `rule` varchar(255) DEFAULT '' COMMENT '权限节点数据',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of qili_role
-- ----------------------------
INSERT INTO `qili_role` VALUES ('1', '超级管理员', '*');
INSERT INTO `qili_role` VALUES ('2', '系统维护员', '1,2,3,4,5,6,7,8,9,10');
INSERT INTO `qili_role` VALUES ('3', '业务经理', '25,26,27,28,29,30,31,39,40,46,41,42,43,44,47,45,48,49');
INSERT INTO `qili_role` VALUES ('4', '济南业务组长', '25,26,27,28,29,30,31,39,40,41,42,43,44,47,45,48,49,50,51,52,53');
INSERT INTO `qili_role` VALUES ('5', '北京业务组长', '25,26,27,28,29,30,31,39,46,41,42,43,44,47,45,48,49');
INSERT INTO `qili_role` VALUES ('6', '业务', '25,26,27,28,29,30,31,41,42,44,47,45,48,50,51,52,53');

-- ----------------------------
-- Table structure for qili_summary
-- ----------------------------
DROP TABLE IF EXISTS `qili_summary`;
CREATE TABLE `qili_summary` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '文章id',
  `user_id` varchar(155) NOT NULL COMMENT '文章关键字',
  `title` varchar(155) NOT NULL COMMENT '文章标题',
  `description` varchar(255) NOT NULL COMMENT '文章描述',
  `content` text NOT NULL COMMENT '文章内容',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '发布时间',
  `update_time` int(11) NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qili_summary
-- ----------------------------
INSERT INTO `qili_summary` VALUES ('6', '1', 'dsummary', 'dsummary', '<p style=\"margin-top: 0px; margin-bottom: 25px; padding: 0px; text-indent: 28px; text-align: justify; word-wrap: break-word; word-break: normal;\">中国天气网讯今天（20日）白天北京以多云天气为主，较适宜户外活动，不过随着气象扩散条件继续转差，预计周日傍晚至周一上午将为气象扩散条件最差阶段，出行需注意健康防护。</p><p class=\"detailPic\" style=\"padding: 0px; text-indent: 28px; word-wrap: break-word; word-break: normal; margin: 0px auto 10px; text-align: center;\"><img title=\"1539991865219088912.jpg\" alt=\"2.jpg\" src=\"/static/upload/image/20181020/1540000098828576.jpg\"/></p><p style=\"margin-top: 0px; margin-bottom: 25px; padding: 0px; text-indent: 28px; text-align: justify; word-wrap: break-word; word-break: normal;\">北京近日早晚天气寒凉，最低气温已不足10℃，秋意渐浓。北京市气象预计，今天白天多云，北转南风2、3级，最高气温18℃；夜间多云，南转北风1、2级，最低气温7℃。今天天气较适宜户外运动，不过山区最低气温更低，局地甚至不足0℃，提醒登高赏秋时增加衣物，注意保暖。</p><p style=\"margin-top: 0px; margin-bottom: 25px; padding: 0px; text-indent: 28px; text-align: justify; word-wrap: break-word; word-break: normal;\">明天开始，气象扩散条件将进一步转差，早晚还易出现轻雾或雾，白天的能见度也会有起伏。预计周日傍晚至周一上午为气象扩散条件最差阶段，出行需注意健康防护。</p><p class=\"detailPic\" style=\"padding: 0px; text-indent: 28px; word-wrap: break-word; word-break: normal; margin: 0px auto 10px; text-align: center;\"><img title=\"1539991848153081413.jpg\" src=\"/static/upload/image/20181020/1540000098126831.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 25px; padding: 0px; text-indent: 28px; text-align: justify; word-wrap: break-word; word-break: normal;\">据北京市气象台预计，10月23日前后开始，北京城区和平原地区银杏将进入观赏初期。而未来一周，北京以晴或多云天气为主，气温整体变化起伏不大，白天气温在19~18℃左右，夜间气温在5~8℃左右，持续低温较有利于银杏变色，提醒大家赏秋叶同时也需注意防寒保暖。<span class=\"ifengLogo\"><a href=\"http://www.ifeng.com/\" target=\"_blank\" style=\"text-decoration-line: none; color: rgb(0, 66, 118); font-weight: bold;\"><img src=\"/static/upload/image/20181020/1540000098111073.png\"/></a></span></p><p><br/></p>', '1539856032', '1540000100');
INSERT INTO `qili_summary` VALUES ('5', '1', 'd', 'd', '<p>d</p>', '1539855359', '1539856239');
INSERT INTO `qili_summary` VALUES ('9', '2', '56465465465', '66564564565', '<p>+9598986553665<br/></p>', '1540001532', '0');
INSERT INTO `qili_summary` VALUES ('10', '3', '我是老赵', 'fd56456665  ', '<p>压标地4554456465656565</p>', '1540005303', '0');

-- ----------------------------
-- Table structure for qili_track_copy
-- ----------------------------
DROP TABLE IF EXISTS `qili_track_copy`;
CREATE TABLE `qili_track_copy` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL COMMENT '客户ID',
  `one_time` int(11) DEFAULT NULL COMMENT '第一次跟进时间',
  `one_enclosure` varchar(255) DEFAULT NULL COMMENT '第一次跟进附件',
  `one_remarks` text COMMENT '第一次跟进备注',
  `two_time` int(11) DEFAULT NULL COMMENT '第二次跟进时间',
  `two_enclosure` varchar(255) DEFAULT NULL COMMENT '第二次跟进附件',
  `two_remarks` text COMMENT '第二次跟进备注',
  `three_time` int(11) DEFAULT NULL COMMENT '第三次跟进时间',
  `three_enclosure` varchar(255) DEFAULT NULL COMMENT '第三次跟进附件',
  `three_remarks` text COMMENT '第三次跟进备注',
  `budget` decimal(10,2) DEFAULT NULL COMMENT '预算',
  `offer` varchar(255) DEFAULT NULL COMMENT '报价',
  `time_limit` datetime DEFAULT NULL COMMENT '工期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qili_track_copy
-- ----------------------------

-- ----------------------------
-- Table structure for qili_user
-- ----------------------------
DROP TABLE IF EXISTS `qili_user`;
CREATE TABLE `qili_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT '用户名',
  `password` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT '密码',
  `head` varchar(255) COLLATE utf8_bin DEFAULT '' COMMENT '头像',
  `login_times` int(11) NOT NULL DEFAULT '0' COMMENT '登陆次数',
  `last_login_ip` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT '最后登录IP',
  `last_login_time` int(11) NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `real_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT '真实姓名',
  `status` int(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `role_id` int(11) NOT NULL DEFAULT '1' COMMENT '用户角色id',
  `address` varchar(255) COLLATE utf8_bin NOT NULL COMMENT '工作所在地区',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of qili_user
-- ----------------------------
INSERT INTO `qili_user` VALUES ('1', 'admin', 'a9ddd2e7bdff202e3e9bca32765e9ba0', '/static/admin/images/profile_small.jpg', '54', '127.0.0.1', '1540367264', '超级管理员', '1', '1', '');
INSERT INTO `qili_user` VALUES ('2', 'liuzijing', '84386805f4fa719c7023544210fea50c', '/static/admin/images/profile_small.jpg', '5', '127.0.0.1', '1540004662', '刘子敬', '1', '4', '济南');
INSERT INTO `qili_user` VALUES ('3', 'zhaojunhao', '84386805f4fa719c7023544210fea50c', '/static/admin/images/profile_small.jpg', '1', '127.0.0.1', '1540005272', '赵俊豪', '1', '6', '济南');
