<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:72:"D:\phpStudy\WWW\qili_crm\public/../application/admin\view\order\add.html";i:1540460246;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>添加账单</title>
    <link rel="shortcut icon" href="favicon.ico">
    <link href="__CSS__/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="__CSS__/font-awesome.min.css?v=4.4.0" rel="stylesheet">
    <link href="__CSS__/animate.min.css" rel="stylesheet">
    <link href="__CSS__/plugins/chosen/chosen.css" rel="stylesheet">
    <link href="__CSS__/style.min.css?v=4.1.0" rel="stylesheet">
    <link href="__JS__/plugins/bootstrap-tagsinput/bootstrap-tagsinput.css" rel="stylesheet">
    <link href="__JS__/layui/css/layui.css"rel="stylesheet">
    <link href="__STATIC__/admin/datepicker/css/foundation-datepicker.css" rel="stylesheet" type="text/css">
    <link href="__CSS__/plugins/chosen/chosen.css" rel="stylesheet">
    <link href="__CSS__/plugins/iCheck/custom.css" rel="stylesheet">
    
</head>
<body class="gray-bg">
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <div class="col-sm-10">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>添加账单</h5>
                </div>
                <div class="ibox-content">
                    <form name="reg_testdate" class="form-horizontal m-t" id="commentForm" method="post" action="<?php echo url('order/add'); ?>">
                        <div class="form-group">
                            <label class="col-sm-3 control-label">订单号：</label>
                            <div class="input-group col-sm-3">
                                <input id="third_order_id" type="text" placeholder="必填" class="form-control" name="third_order_id">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">项目名称：</label>
                            <div class="input-group col-sm-3">
                                <input id="project_name" type="text" placeholder="必填" class="form-control" name="project_name">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">联系人：</label>
                            <div class="input-group col-sm-3">
                                <input id="customer" type="text" placeholder="必填" class="form-control" name="customer">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">电话：</label>
                            <div class="input-group col-sm-3">
                                <input id="phone" type="number" oninput="if(value.length>8)value=value.slice(0,8)" placeholder="必填" class="form-control" name="phone">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">总金额：</label>
                            <div class="input-group col-sm-3">
                                <input id="total_amount" type="number" oninput="if(value.length>8)value=value.slice(0,8)" placeholder="必填" class="form-control" name="total_amount">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">提醒时间：</label>
                            <div class="input-group col-sm-3" id="datepicker">
                              <input type="text" style="width:120px;" placeholder="选择提醒时间" class="form-control" name="reminding_time" id="reminding_time" value="">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">分几批：</label>
                            <div class="input-group col-sm-3">
                                <input id="batch" type="text" placeholder="必填" class="form-control" name="batch">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">第一批回款金额：</label>
                            <div class="input-group col-sm-3">
                                <input id="first_batch_backamount" type="number" oninput="if(value.length>8)value=value.slice(0,8)" placeholder="选填" class="form-control" name="first_batch_backamount">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">回款时间：</label>
                            <div class="input-group col-sm-3" id="datepicker">
                              <input type="text" style="width:120px;" placeholder="选择回款时间" class="form-control" name="first_batch_backtime" id="first_batch_backtime" value="">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">第二批回款金额：</label>
                            <div class="input-group col-sm-3">
                                <input id="second_batch_backamount" type="number" oninput="if(value.length>8)value=value.slice(0,8)" placeholder="选填" class="form-control" name="second_batch_backamount">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">回款时间：</label>
                            <div class="input-group col-sm-3" id="datepicker">
                              <input type="text" style="width:120px;" placeholder="选择回款时间" class="form-control" name="second_batch_backtime" id="second_batch_backtime" value="">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">第三批回款金额：</label>
                            <div class="input-group col-sm-3">
                                <input id="third_batch_backamount" type="number" oninput="if(value.length>8)value=value.slice(0,8)" placeholder="选填" class="form-control" name="third_batch_backamount">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">回款时间：</label>
                            <div class="input-group col-sm-3" id="datepicker">
                              <input type="text" style="width:120px;" placeholder="选择回款时间" class="form-control" name="third_batch_backtime" id="third_batch_backtime" value="">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">客户评价：</label>
                            <input name="customer_evaluation" id="customer_evaluation" type="hidden"/>
                            <div class="form-inline">
                                <div class="input-group col-sm-8">
                                    <button type="button" class="layui-btn" id="test1">
                                        <i class="layui-icon">&#xe67c;</i>上传图片
                                    </button>
                                    <div style="margin-top:10px;" ><img id="sm" src="__STATIC__/admin/images/no_img.jpg" height="200" >   建议上传尺寸:900*400像素的图片</div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">进度状态：</label>
                            <div class="input-group col-sm-6">
                                <div class="radio i-checks col-sm-3">
                                    <label><input type="radio" value="1" name="status"> <i></i>已完成</label>
                                </div>
                                <div class="radio i-checks col-sm-3">
                                    <label><input type="radio" value="2" checked="checked" name="status"> <i></i>未回款</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">是否退款：</label>
                            <div class="input-group col-sm-6">
                                <div class="radio i-checks col-sm-3">
                                    <label><input type="radio" value="1" name="is_refund"> <i></i>是</label>
                                </div>
                                <div class="radio i-checks col-sm-3">
                                    <label><input type="radio" value="2" checked="checked" name="is_refund"> <i></i>否</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">退款时间：</label>
                            <div class="input-group col-sm-3" id="datepicker">
                              <input type="text" style="width:120px;" placeholder="选择退款时间" class="form-control" name="refund_time" id="refund_time" value="">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">退款金额：</label>
                            <div class="input-group col-sm-3">
                                <input id="refund_amount" type="number" oninput="if(value.length>8)value=value.slice(0,8)" placeholder="" class="form-control" name="refund_amount">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-4 col-sm-offset-5">
                                <button class="btn btn-primary" type="submit">提交</button>
                                <a class="btn btn-default" type="button" href="javascript:history.go(-1);">取消</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
<script src="__JS__/jquery.min.js?v=2.1.4"></script>
<script src="__JS__/bootstrap.min.js?v=3.3.6"></script>
<script src="__JS__/content.min.js?v=1.0.0"></script>
<script src="__JS__/plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>
<script src="__JS__/plugins/validate/jquery.validate.min.js"></script>
<script src="__JS__/plugins/validate/messages_zh.min.js"></script>
<script src="__JS__/plugins/chosen/chosen.jquery.js"></script>
<script src="__JS__/layui/layui.js"></script>
<script src="__JS__/jquery.form.js"></script>
<script src="__STATIC__/admin/datepicker/js/foundation-datepicker.js"></script>
<script src="__STATIC__/admin/datepicker/js/locales/foundation-datepicker.zh-CN.js"></script>  
<script src="__JS__/plugins/chosen/chosen.jquery.js"></script>
<script src="__JS__/plugins/iCheck/icheck.min.js"></script>
<script>
    $('#first_batch_backtime').fdatepicker({
        format: 'yyyy-mm-dd',
    });
    $('#second_batch_backtime').fdatepicker({
        format: 'yyyy-mm-dd',
    });
    $('#third_batch_backtime').fdatepicker({
        format: 'yyyy-mm-dd',
    });
    $('#reminding_time').fdatepicker({
        format: 'yyyy-mm-dd',
    });
    $('#refund_time').fdatepicker({
        format: 'yyyy-mm-dd',
    });
</script>
<script type="text/javascript">
    var index = '';
    function showStart(){
        index = layer.load(0, {shade: false});
        return true;
    }
    function showSuccess(res){
        console.log(res);
        layer.ready(function(){
            layer.close(index);
            if(1 == res.code){
                layer.alert(res.msg, {title: '友情提示', icon: 1, closeBtn: 0}, function(){
                    window.location.href = res.data;
                });
            }else if(111 == res.code){
                window.location.reload();
            }else{
                layer.msg(res.msg, {anim: 6});
            }
        });
    }
    $(document).ready(function(){
        $(".i-checks").iCheck({checkboxClass:"icheckbox_square-green",radioClass:"iradio_square-green",});
        // 添加角色
        var options = {
            beforeSubmit:showStart,
            success:showSuccess
        };

        $('#commentForm').submit(function(){
            $(this).ajaxSubmit(options);
            return false;
        });

        $('#keywords').tagsinput('add', 'some tag');
        $(".bootstrap-tagsinput").addClass('col-sm-12').find('input').addClass('form-control')
            .attr('placeholder', '输入后按enter');
         // 上传图片
        layui.use('upload', function(){
            var upload = layui.upload;

            //执行实例
            var uploadInst = upload.render({
                elem: '#test1' //绑定元素
                ,url: "<?php echo url('order/uploadImg'); ?>" //上传接口
                ,done: function(res){
                    //上传完毕回调
                    $("#customer_evaluation").val(res.data.src);
                    // $("#sm").html('<img src="' + res.data.src + '" style="height: 40px;"/>');
                    $("#sm").attr('src',res.data.src);
                }
                ,error: function(){
                    //请求异常回调
                }
            });
        });

        // var editor = UE.getEditor('container');
    });

    // 表单验证
    $.validator.setDefaults({
        highlight: function(e) {
            $(e).closest(".form-group").removeClass("has-success").addClass("has-error")
        },
        success: function(e) {
            e.closest(".form-group").removeClass("has-error").addClass("has-success")
        },
        errorElement: "span",
        errorPlacement: function(e, r) {
            e.appendTo(r.is(":radio") || r.is(":checkbox") ? r.parent().parent().parent() : r.parent())
        },
        errorClass: "help-block m-b-none",
        validClass: "help-block m-b-none"
    });

    // var config = {
    //     '.chosen-select': {},
    // }
    // for (var selector in config) {
    //     $(selector).chosen(config[selector]);
    // }
</script>
</body>
</html>
