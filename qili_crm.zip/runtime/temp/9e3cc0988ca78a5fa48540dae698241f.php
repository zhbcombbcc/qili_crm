<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:77:"D:\phpStudy\WWW\qili_crm\public/../application/admin\view\customer\track.html";i:1540622572;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>状态跟进</title>
    <link rel="shortcut icon" href="favicon.ico">
    <link href="__CSS__/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="__CSS__/font-awesome.min.css?v=4.4.0" rel="stylesheet">
    <link href="__CSS__/animate.min.css" rel="stylesheet">
    <link href="__CSS__/plugins/chosen/chosen.css" rel="stylesheet">
    <link href="__CSS__/style.min.css?v=4.1.0" rel="stylesheet">
    <link href="__JS__/plugins/bootstrap-tagsinput/bootstrap-tagsinput.css" rel="stylesheet">
    <link href="__JS__/layui/css/layui.css"rel="stylesheet">
    <link href="__STATIC__/admin/datepicker/css/foundation-datepicker.css" rel="stylesheet" type="text/css">
    <link href="__CSS__/plugins/chosen/chosen.css" rel="stylesheet">
    <link href="__CSS__/plugins/iCheck/custom.css" rel="stylesheet">
    
</head>
<body class="gray-bg">
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <div class="col-sm-10">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>状态跟进</h5>
                </div>
                <div class="ibox-content">
                    <form name="reg_testdate" class="form-horizontal m-t" id="commentForm" method="post" action="<?php echo url('customer/track'); ?>">
                        <input type="hidden" name="id" value="<?php echo $customer['id']; ?>"/>
                        <!-- 第一次跟进 -->
                        <div class="form-group">
                            <label class="col-sm-3 control-label" style="font-size:20px;">一次跟进</label>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">跟进时间：</label>
                            <div class="input-group col-sm-3" id="datepicker">
                              <input type="text" style="width:120px;" placeholder="选择跟进时间" class="form-control" name="one_time" id="one_time" value="<?php echo $customer['one_time']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">添加附件：</label>
                            <div class="input-group col-sm-4">
                                <div id="file-pretty">
                                    <input id="one_enclosure" name="one_enclosure" type="file" class="form-control" style="display:none">
                                    <div class="input-append input-group">
                                        <span class="input-group-btn">
                                            <button id="one_enclosure_btn" type="button" class="btn btn-primary">选择文档</button>
                                        </span>
                                        <input type="text" placeholder="上传需求文件" class="form-control input-large" name='one_enclosure_path' id="one_enclosure_path" value="<?php echo $customer['demand_file_path']; ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">备注：</label>
                            <div class="input-group col-sm-4">
                                <textarea class="form-control" name="one_remarks" id="one_remarks" rows="5"><?php echo $customer['one_remarks']; ?></textarea>
                            </div>
                        </div>
                        <!-- 第二次跟进 -->
                        <div class="form-group">
                            <label class="col-sm-3 control-label" style="font-size:20px;">二次跟进</label>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">跟进时间：</label>
                            <div class="input-group col-sm-3" id="datepicker">
                              <input type="text" style="width:120px;" placeholder="选择跟进时间" class="form-control" name="two_time" id="two_time" value="<?php echo $customer['two_time']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">添加附件：</label>
                            <div class="input-group col-sm-4">
                                <div id="file-pretty">
                                    <input id="two_enclosure" name="two_enclosure" type="file" class="form-control" style="display:none">
                                    <div class="input-append input-group">
                                        <span class="input-group-btn">
                                            <button id="two_enclosure_btn" type="button" class="btn btn-primary">选择文档</button>
                                        </span>
                                        <input type="text" placeholder="上传需求文件" class="form-control input-large" name='two_enclosure_path' id="two_enclosure_path" value="<?php echo $customer['two_enclosure_path']; ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">备注：</label>
                            <div class="input-group col-sm-4">
                                <textarea class="form-control" name="two_remarks" id="two_remarks" rows="5"><?php echo $customer['two_remarks']; ?></textarea>
                            </div>
                        </div>
                        <!-- 第三次跟进 -->
                        <div class="form-group">
                            <label class="col-sm-3 control-label" style="font-size:20px;">三次跟进</label>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">跟进时间：</label>
                            <div class="input-group col-sm-3" id="datepicker">
                              <input type="text" style="width:120px;" placeholder="选择跟进时间" class="form-control" name="three_time" id="three_time" value="<?php echo $customer['three_time']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">添加附件：</label>
                            <div class="input-group col-sm-4">
                                <div id="file-pretty">
                                    <input id="three_enclosure" name="three_enclosure" type="file" class="form-control" style="display:none">
                                    <div class="input-append input-group">
                                        <span class="input-group-btn">
                                            <button id="three_enclosure_btn" type="button" class="btn btn-primary">选择文档</button>
                                        </span>
                                        <input type="text" placeholder="上传需求文件" class="form-control input-large" name='three_enclosure_path' id="three_enclosure_path" value="<?php echo $customer['three_enclosure_path']; ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">备注：</label>
                            <div class="input-group col-sm-4">
                                <textarea class="form-control" name="three_remarks" id="three_remarks" rows="5"><?php echo $customer['three_remarks']; ?></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">项目预算：</label>
                            <div class="input-group col-sm-3">
                                <input type="text" placeholder="必填" class="form-control" name="budget" id="budget" value="<?php echo $customer['budget']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">项目报价：</label>
                            <div class="input-group col-sm-3">
                                <input type="text" placeholder="必填" class="form-control" name="offer" id="offer" value="<?php echo $customer['offer']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">项目工期：</label>
                            <div class="input-group col-sm-3">
                                <input type="text" placeholder="必填" class="form-control" name="time_limit" id="time_limit" value="<?php echo $customer['time_limit']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-4 col-sm-offset-5">
                                <button class="btn btn-primary" type="submit">提交</button>
                                <a class="btn btn-default" type="button" href="javascript:history.go(-1);">取消</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>

<script src="__JS__/jquery.min.js?v=2.1.4"></script>
<script src="__STATIC__/admin/js/ajaxfileupload.js"></script>
<script src="__JS__/bootstrap.min.js?v=3.3.6"></script>
<script src="__JS__/content.min.js?v=1.0.0"></script>
<script src="__JS__/plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>
<script src="__JS__/plugins/validate/jquery.validate.min.js"></script>
<script src="__JS__/plugins/validate/messages_zh.min.js"></script>
<script src="__JS__/plugins/chosen/chosen.jquery.js"></script>
<script src="__JS__/layui/layui.js"></script>
<script src="__JS__/jquery.form.js"></script>
<script src="__STATIC__/admin/datepicker/js/foundation-datepicker.js"></script>
<script src="__STATIC__/admin/datepicker/js/locales/foundation-datepicker.zh-CN.js"></script>  
<script src="__JS__/plugins/iCheck/icheck.min.js"></script>
<script src="__JS__/plugins/layer/layer.min.js"></script>
<script type="text/javascript">
    // 上传需求文档
    $(function(){
        $('#one_enclosure_btn').click(function(){
            $("#one_enclosure").click();
        });

        //异步上传
        $("body").delegate("#one_enclosure", 'change', function(){
            var filepath = $("input[name='one_enclosure']").val();
            var arr = filepath.split('.');
            var ext = arr[arr.length-1];//图片后缀
            // gif|jpg|png|bmp|
            if('docx|doc|ppt|xlsx|xls'.indexOf(ext)>=0){
                $.ajaxFileUpload({
                   url: "<?php echo url('customer/upload'); ?>",
                   type: 'post',
                   data: { name: 'one_enclosure' },
                   secureuri: false,
                   fileElementId: 'one_enclosure',
                   dataType: 'json',
                   success: function (data, status) {
                        // console.log(data)
                       $('#one_enclosure_path').val(data.fileName);
                       $('#one_enclosure_path').focus();
                   },
                   error: function (data, status, e){
                       layer.alert('上传失败');
                   }
                });
            }else{
                // 清空file
                $('#one_enclosure').val('');
                layer.alert('请上传合适的文件类型');
            }
        });
    });
</script>
<script type="text/javascript">
    // 上传需求文档
    $(function(){
        $('#two_enclosure_btn').click(function(){
            $("#two_enclosure").click();
        });

        //异步上传
        $("body").delegate("#two_enclosure", 'change', function(){
            var filepath = $("input[name='two_enclosure']").val();
            var arr = filepath.split('.');
            var ext = arr[arr.length-1];//图片后缀
            // gif|jpg|png|bmp|
            if('docx|doc|ppt|xlsx|xls'.indexOf(ext)>=0){
                $.ajaxFileUpload({
                   url: "<?php echo url('customer/upload'); ?>",
                   type: 'post',
                   data: { name: 'two_enclosure' },
                   secureuri: false,
                   fileElementId: 'two_enclosure',
                   dataType: 'json',
                   success: function (data, status) {
                        // console.log(data)
                       $('#two_enclosure_path').val(data.fileName);
                       $('#two_enclosure_path').focus();
                   },
                   error: function (data, status, e){
                       layer.alert('上传失败');
                   }
                });
            }else{
                // 清空file
                $('#two_enclosure').val('');
                layer.alert('请上传合适的文件类型');
            }
        });
    });
</script>
<script type="text/javascript">
    // 上传需求文档
    $(function(){
        $('#three_enclosure_btn').click(function(){
            $("#three_enclosure").click();
        });

        //异步上传
        $("body").delegate("#three_enclosure", 'change', function(){
            var filepath = $("input[name='three_enclosure']").val();
            var arr = filepath.split('.');
            var ext = arr[arr.length-1];//图片后缀
            // gif|jpg|png|bmp|
            if('docx|doc|ppt|xlsx|xls'.indexOf(ext)>=0){
                $.ajaxFileUpload({
                   url: "<?php echo url('customer/upload'); ?>",
                   type: 'post',
                   data: { name: 'three_enclosure' },
                   secureuri: false,
                   fileElementId: 'three_enclosure',
                   dataType: 'json',
                   success: function (data, status) {
                        // console.log(data)
                       $('#three_enclosure_path').val(data.fileName);
                       $('#three_enclosure_path').focus();
                   },
                   error: function (data, status, e){
                       layer.alert('上传失败');
                   }
                });
            }else{
                // 清空file
                $('#three_enclosure').val('');
                layer.alert('请上传合适的文件类型');
            }
        });
    });
</script>
<script type="text/javascript">
    $('#one_time').fdatepicker({
        format: 'yyyy-mm-dd',
    });
    $('#two_time').fdatepicker({
        format: 'yyyy-mm-dd',
    });
    $('#three_time').fdatepicker({
        format: 'yyyy-mm-dd',
    });

    var index = '';
    function showStart(){
        index = layer.load(0, {shade: false});
        return true;
    }

    function showSuccess(res){
        console.log(res);
        layer.ready(function(){
            layer.close(index);
            if(1 == res.code){
                layer.alert(res.msg, {title: '友情提示', icon: 1, closeBtn: 0}, function(){
                    window.location.href = res.data;
                });
            }else if(111 == res.code){
                window.location.reload();
            }else{
                layer.msg(res.msg, {anim: 6});
            }
        });
    }

    $(document).ready(function(){
        $(".i-checks").iCheck({checkboxClass:"icheckbox_square-green",radioClass:"iradio_square-green",});
        // 添加角色
        var options = {
            beforeSubmit:showStart,
            success:showSuccess
        };

        $('#commentForm').submit(function(){
            $(this).ajaxSubmit(options);
            return false;
        });
    });

    // 表单验证
    $.validator.setDefaults({
        highlight: function(e) {
            $(e).closest(".form-group").removeClass("has-success").addClass("has-error")
        },
        success: function(e) {
            e.closest(".form-group").removeClass("has-error").addClass("has-success")
        },
        errorElement: "span",
        errorPlacement: function(e, r) {
            e.appendTo(r.is(":radio") || r.is(":checkbox") ? r.parent().parent().parent() : r.parent())
        },
        errorClass: "help-block m-b-none",
        validClass: "help-block m-b-none"
    });

    // var config = {
    //     '.chosen-select': {},
    // }
    // for (var selector in config) {
    //     $(selector).chosen(config[selector]);
    // }
</script>
</body>
</html>
