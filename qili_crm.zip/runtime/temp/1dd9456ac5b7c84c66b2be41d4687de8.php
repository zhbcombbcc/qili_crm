<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"D:\phpStudy\WWW\qili_crm\public/../application/admin\view\index\index.html";i:1539415577;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>后台首页</title>
    <link rel="shortcut icon" href="favicon.ico">
    <link href="https://cdn.bootcss.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.staticfile.org/font-awesome/4.4.0/css/font-awesome.css?v=4.4.0" rel="stylesheet">
    <link href="https://cdn.bootcss.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
    <link href="__CSS__/style.min.css?v=4.1.0" rel="stylesheet">
</head>
<body class="gray-bg">
<div class="wrapper wrapper-content">
    <div class="row">
        <div class="col-sm-8">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>系统信息</h5>
                    <div class="ibox-tools">
                        <a class="collapse-link">
                            <i class="fa fa-chevron-up"></i>
                        </a>
                        <a class="close-link">
                            <i class="fa fa-times"></i>
                        </a>
                    </div>
                </div>
                <div class="ibox-content">
                    <table class="table table-hover no-margins">
                        <thead>
                            <tr>
                                <td>当前域名：<?php echo $info['SERVER_NAME']; ?></td>
                            </tr>
                            <tr>
                                <td>框架版本：ThinkPHP <?php echo $info['ThinkPHPTYE']; ?></td>    
                            </tr>
                            <tr>
                                <td>上传最大限制：<?php echo $info['ONLOAD']; ?></td>
                            </tr> 
                            <tr>
                                <td>运行环境：<?php echo $info['PCTYPE']; ?></td>
                            </tr>
                            <tr>
                                <td>服务器版本：<?php echo $info['RUNTYPE']; ?></td>
                            </tr>
                            <tr>
                                <td>PHP版本：<?php echo phpversion();?></td>
                            </tr>
                            <tr>
                                <td>MYSQL版本：<?php echo $info['MYSQLVERSION']; ?></td>
                            </tr>
                            <tr>
                                <td>PHP运行方式：<?php echo  php_sapi_name()?></td>
                            </tr>
                        </thead>                                 
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.staticfile.org/jquery/2.1.4/jquery.min.js"></script>
<script src="https://cdn.bootcss.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script src="__JS__/plugins/echarts/echarts-all.js"></script>
<script type="text/javascript">
    
</script>
</body>
</html>
