<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:76:"D:\phpStudy\WWW\qili_crm\public/../application/admin\view\customer\deal.html";i:1540633430;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>成交填写</title>
    <link rel="shortcut icon" href="favicon.ico">
    <link href="__CSS__/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="__CSS__/font-awesome.min.css?v=4.4.0" rel="stylesheet">
    <link href="__CSS__/animate.min.css" rel="stylesheet">
    <link href="__CSS__/plugins/chosen/chosen.css" rel="stylesheet">
    <link href="__CSS__/style.min.css?v=4.1.0" rel="stylesheet">
    <link href="__JS__/plugins/bootstrap-tagsinput/bootstrap-tagsinput.css" rel="stylesheet">
    <link href="__JS__/layui/css/layui.css"rel="stylesheet">
    <link href="__STATIC__/admin/datepicker/css/foundation-datepicker.css" rel="stylesheet" type="text/css">
    <link href="__CSS__/plugins/chosen/chosen.css" rel="stylesheet">
    <link href="__CSS__/plugins/iCheck/custom.css" rel="stylesheet">
    
</head>
<body class="gray-bg">
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <div class="col-sm-10">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>成交填写</h5>
                </div>
                <div class="ibox-content">
                    <form name="reg_testdate" class="form-horizontal m-t" id="commentForm" method="post" action="<?php echo url('customer/deal'); ?>">
                        <input type="hidden" name="id" value="<?php echo $customer['id']; ?>"/>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">订单号：</label>
                            <div class="input-group col-sm-5">
                                <input id="third_customer_id" type="text" placeholder="必填" class="form-control" name="third_customer_id" value="<?php echo $customer['order']['third_order_id']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">总金额：</label>
                            <div class="input-group col-sm-5">
                                <input id="total_amount" type="text" placeholder="必填" class="form-control" name="total_amount" value="<?php echo $customer['order']['total_amount']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">分几批：</label>
                            <div class="input-group col-sm-5">
                                <input id="batch" type="text" placeholder="必填" class="form-control" name="batch" value="<?php echo $customer['order']['batch']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">电话座机：</label>
                            <div class="input-group col-sm-5">
                                <input id="telephone" type="number" oninput="if(value.length>11)value=value.slice(0,11)" placeholder="必填" class="form-control" name="telephone" value="<?php echo $customer['order']['telephone']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">项目名称：</label>
                            <div class="input-group col-sm-5">
                                <input id="project_name" type="text" placeholder="必填" class="form-control" name="project_name" value="<?php echo $customer['order']['project_name']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">项目分类：</label>
                            <div class="input-group col-sm-5">
                                <select class="form-control" name="source" id="source">
                                    <option value="0">--选择项目分类--</option>
                                    <option value="1" <?php echo !empty($customer['order']['project_cate_id']) && $customer['order']['project_cate_id']==1?'selected' : ''; ?>>网站</option>
                                    <option value="2" <?php echo !empty($customer['order']['project_cate_id']) && $customer['order']['project_cate_id']==2?'selected' : ''; ?>>APP</option>
                                    <option value="3" <?php echo !empty($customer['order']['project_cate_id']) && $customer['order']['project_cate_id']==3?'selected' : ''; ?>>公众号</option>
                                    <option value="4" <?php echo !empty($customer['order']['project_cate_id']) && $customer['order']['project_cate_id']==4?'selected' : ''; ?>>小程序</option>
                                    <option value="5" <?php echo !empty($customer['order']['project_cate_id']) && $customer['order']['project_cate_id']==5?'selected' : ''; ?>>套餐</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">项目工期：</label>
                            <div class="input-group col-sm-5">
                                <input type="text" placeholder="必填" class="form-control" name="time_limit" id="time_limit" value="<?php echo $customer['order']['time_limit']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">开始时间：</label>
                            <div class="input-group col-sm-5" id="datepicker">
                              <input type="text" style="width:120px;" placeholder="选择开始时间" class="form-control" name="start_time" id="start_time" value="<?php echo $customer['order']['start_time']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">结束时间：</label>
                            <div class="input-group col-sm-5" id="datepicker">
                              <input type="text" style="width:120px;" placeholder="选择结束时间" class="form-control" name="end_time" id="end_time" value="<?php echo $customer['order']['end_time']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">提醒时间：</label>
                            <div class="input-group col-sm-5">
                                <select name="renew_reminding" class="form-control" id="renew_reminding">
                                    <option value="0">--选择提醒时间--</option>
                                    <option value="1" <?php echo !empty($customer['order']['renew_reminding']) && $customer['order']['renew_reminding']==1?'selected' : ''; ?> >到期前一周</option>
                                    <option value="2" <?php echo !empty($customer['order']['renew_reminding']) && $customer['order']['renew_reminding']==2?'selected' : ''; ?> >到期前二周</option>
                                    <option value="3" <?php echo !empty($customer['order']['renew_reminding']) && $customer['order']['renew_reminding']==3?'selected' : ''; ?> >到期前三周</option>
                                    <option value="4" <?php echo !empty($customer['order']['renew_reminding']) && $customer['order']['renew_reminding']==4?'selected' : ''; ?> >到期前一月</option>
                                    <option value="5" <?php echo !empty($customer['order']['renew_reminding']) && $customer['order']['renew_reminding']==5?'selected' : ''; ?> >到期前三月</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">添加合同：</label>
                            <div class="input-group col-sm-5">
                                <div id="file-pretty">
                                    <input id="contract_file" name="contract_file" type="file" class="form-control" style="display:none">
                                    <div class="input-append input-group">
                                        <span class="input-group-btn">
                                            <button id="contract_path_btn" type="button" class="btn btn-primary">选择文档</button>
                                        </span>
                                        <input type="text" placeholder="上传需求文件" class="form-control input-large" name='contract_path' id="contract_path" value="<?php echo $customer['order']['contract_path']; ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">需求文档：</label>
                            <div class="input-group col-sm-5">
                                <div id="file-pretty">
                                    <input id="require_doc" name="require_doc" type="file" class="form-control" style="display:none">
                                    <div class="input-append input-group">
                                        <span class="input-group-btn">
                                            <button id="require_doc_btn" type="button" class="btn btn-primary">选择文档</button>
                                        </span>
                                        <input type="text" placeholder="上传需求文件" class="form-control input-large" name='require_doc_path' id="require_doc_path" value="<?php echo $customer['order']['require_doc_path']; ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">备注：</label>
                            <div class="input-group col-sm-5">
                                <textarea class="form-control" name="remarks" id="remarks" rows="5"><?php echo $customer['order']['remarks']; ?></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">是否回款：</label>
                            <div class="input-group col-sm-5">
                                <div class="radio i-checks col-sm-3">
                                    <label><input type="radio" value="1" <?php echo !empty($customer['order']['is_return_money']) && $customer['order']['is_return_money']==1?"checked" : ''; ?> name="is_return_money"> <i></i>是</label>
                                </div>
                                <div class="radio i-checks col-sm-3">
                                    <label><input type="radio" value="2" <?php echo !empty($customer['order']['is_return_money']) && $customer['order']['is_return_money']==2?"checked" : ''; ?>  <?php echo !empty($customer['order']['is_return_money'])?"" : 'checked'; ?> name="is_return_money"> <i></i>否</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">是否赠送服务器：</label>
                            <div class="input-group col-sm-5">
                                <div class="radio i-checks col-sm-3">
                                    <label><input type="radio" value="1" <?php echo !empty($customer['order']['is_gift_server']) && $customer['order']['is_gift_server']==1?"checked" : ''; ?> name="is_gift_server"> <i></i>是</label>
                                </div>
                                <div class="radio i-checks col-sm-3">
                                    <label><input type="radio" value="2" <?php echo !empty($customer['order']['is_gift_server']) && $customer['order']['is_gift_server']==2?"checked" : ''; ?> <?php echo !empty($customer['order']['is_gift_server'])?"" : 'checked'; ?> name="is_gift_server"> <i></i>否</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">是否赠送空间：</label>
                            <div class="input-group col-sm-5">
                                <div class="radio i-checks col-sm-3">
                                    <label><input type="radio" value="1" <?php echo !empty($customer['order']['is_gift_space']) && $customer['order']['is_gift_space']==1?"checked" : ''; ?> name="is_gift_space"> <i></i>是</label>
                                </div>
                                <div class="radio i-checks col-sm-3">
                                    <label><input type="radio" value="2" <?php echo !empty($customer['order']['is_gift_space']) && $customer['order']['is_gift_space']==2?"checked" : ''; ?> <?php echo !empty($customer['order']['is_gift_space'])?"" : 'checked'; ?> name="is_gift_space"> <i></i>否</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">需付费金额：</label>
                            <div class="input-group col-sm-5">
                                <input type="text" placeholder="必填" class="form-control" name="pay_amount" id="pay_amount" value="<?php echo $customer['order']['pay_amount']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">是否赠送域名：</label>
                            <div class="input-group col-sm-5">
                                <div class="radio i-checks col-sm-3">
                                    <label><input type="radio" value="1" <?php echo !empty($customer['order']['is_gift_domain']) && $customer['order']['is_gift_domain']==1?"checked" : ''; ?> name="is_gift_domain"> <i></i>是</label>
                                </div>
                                <div class="radio i-checks col-sm-3">
                                    <label><input type="radio" value="2" <?php echo !empty($customer['order']['is_gift_domain']) && $customer['order']['is_gift_domain']==2?"checked" : ''; ?> <?php echo !empty($customer['order']['is_gift_domain'])?"" : 'checked'; ?> name="is_gift_domain"> <i></i>否</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">是否续费：</label>
                            <div class="input-group col-sm-5">
                                <div class="radio i-checks col-sm-3">
                                    <label><input type="radio" value="1" <?php echo !empty($customer['order']['is_renew']) && $customer['order']['is_renew']==1?"checked" : ''; ?> name="is_renew"> <i></i>是</label>
                                </div>
                                <div class="radio i-checks col-sm-3">
                                    <label><input type="radio" value="2" <?php echo !empty($customer['order']['is_renew']) && $customer['order']['is_renew']==2?"checked" : ''; ?> <?php echo !empty($customer['order']['is_renew'])?"" : 'checked'; ?> name="is_renew"> <i></i>否</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-4 col-sm-offset-5">
                                <button class="btn btn-primary" type="submit">提交</button>
                                <a class="btn btn-default" type="button" href="javascript:history.go(-1);">取消</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>

<script src="__JS__/jquery.min.js?v=2.1.4"></script>
<script src="__STATIC__/admin/js/ajaxfileupload.js"></script>
<script src="__JS__/bootstrap.min.js?v=3.3.6"></script>
<script src="__JS__/content.min.js?v=1.0.0"></script>
<script src="__JS__/plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>
<script src="__JS__/plugins/validate/jquery.validate.min.js"></script>
<script src="__JS__/plugins/validate/messages_zh.min.js"></script>
<script src="__JS__/plugins/chosen/chosen.jquery.js"></script>
<script src="__JS__/layui/layui.js"></script>
<script src="__JS__/jquery.form.js"></script>
<script src="__STATIC__/admin/datepicker/js/foundation-datepicker.js"></script>
<script src="__STATIC__/admin/datepicker/js/locales/foundation-datepicker.zh-CN.js"></script>  
<script src="__JS__/plugins/iCheck/icheck.min.js"></script>
<script src="__JS__/plugins/layer/layer.min.js"></script>
<script type="text/javascript">
    // 上传需求文档
    $(function(){
        $('#contract_path_btn').click(function(){
            $("#contract_file").click();
        });

        //异步上传
        $("body").delegate("#contract_file", 'change', function(){
            var filepath = $("input[name='contract_file']").val();
            var arr = filepath.split('.');
            var ext = arr[arr.length-1];//图片后缀
            // gif|jpg|png|bmp|
            if('docx|doc|ppt|xlsx|xls'.indexOf(ext)>=0){
                $.ajaxFileUpload({
                   url: "<?php echo url('customer/upload'); ?>",
                   type: 'post',
                   data: { name: 'contract_file' },
                   secureuri: false,
                   fileElementId: 'contract_file',
                   dataType: 'json',
                   success: function (data, status) {
                        // console.log(data)
                       $('#contract_path').val(data.fileName);
                       $('#contract_path').focus();
                   },
                   error: function (data, status, e){
                       layer.alert('上传失败');
                   }
                });
            }else{
                // 清空file
                $('#contract_file').val('');
                layer.alert('请上传合适的文件类型');
            }
        });
    });
</script>
<script type="text/javascript">
    // 上传需求文档
    $(function(){
        $('#require_doc_btn').click(function(){
            $("#require_doc").click();
        });

        //异步上传
        $("body").delegate("#require_doc", 'change', function(){
            var filepath = $("input[name='require_doc']").val();
            var arr = filepath.split('.');
            var ext = arr[arr.length-1];//图片后缀
            // gif|jpg|png|bmp|
            if('docx|doc|ppt|xlsx|xls'.indexOf(ext)>=0){
                $.ajaxFileUpload({
                   url: "<?php echo url('customer/upload'); ?>",
                   type: 'post',
                   data: { name: 'require_doc' },
                   secureuri: false,
                   fileElementId: 'require_doc',
                   dataType: 'json',
                   success: function (data, status) {
                        // console.log(data)
                       $('#require_doc_path').val(data.fileName);
                       $('#require_doc_path').focus();
                   },
                   error: function (data, status, e){
                       layer.alert('上传失败');
                   }
                });
            }else{
                // 清空file
                $('#require_doc').val('');
                layer.alert('请上传合适的文件类型');
            }
        });
    });
</script>
<script type="text/javascript">
    $('#start_time').fdatepicker({
        format: 'yyyy-mm-dd',
    });
    $('#end_time').fdatepicker({
        format: 'yyyy-mm-dd',
    });
    var index = '';
    function showStart(){
        index = layer.load(0, {shade: false});
        return true;
    }

    function showSuccess(res){
        console.log(res);
        layer.ready(function(){
            layer.close(index);
            if(1 == res.code){
                layer.alert(res.msg, {title: '友情提示', icon: 1, closeBtn: 0}, function(){
                    window.location.href = res.data;
                });
            }else if(111 == res.code){
                window.location.reload();
            }else{
                layer.msg(res.msg, {anim: 6});
            }
        });
    }

    $(document).ready(function(){
        $(".i-checks").iCheck({checkboxClass:"icheckbox_square-green",radioClass:"iradio_square-green",});
        // 添加角色
        var options = {
            beforeSubmit:showStart,
            success:showSuccess
        };

        $('#commentForm').submit(function(){
            $(this).ajaxSubmit(options);
            return false;
        });
    });

    // 表单验证
    $.validator.setDefaults({
        highlight: function(e) {
            $(e).closest(".form-group").removeClass("has-success").addClass("has-error")
        },
        success: function(e) {
            e.closest(".form-group").removeClass("has-error").addClass("has-success")
        },
        errorElement: "span",
        errorPlacement: function(e, r) {
            e.appendTo(r.is(":radio") || r.is(":checkbox") ? r.parent().parent().parent() : r.parent())
        },
        errorClass: "help-block m-b-none",
        validClass: "help-block m-b-none"
    });

    // var config = {
    //     '.chosen-select': {},
    // }
    // for (var selector in config) {
    //     $(selector).chosen(config[selector]);
    // }
</script>
</body>
</html>
