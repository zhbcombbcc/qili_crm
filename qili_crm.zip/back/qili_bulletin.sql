SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS `qili_bulletin`;
CREATE TABLE `qili_bulletin` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '文章id',
  `title` varchar(155) NOT NULL COMMENT '文章标题',
  `content` text NOT NULL COMMENT '文章内容',
  `time` int(11) NOT NULL COMMENT '发布时间',
  `user_id` int(255) DEFAULT NULL COMMENT '发布人',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;

insert into `qili_bulletin`(`id`,`title`,`content`,`time`,`user_id`) values('53','放入放放入放','<p>455445</p>','2018','1');
insert into `qili_bulletin`(`id`,`title`,`content`,`time`,`user_id`) values('54','上班制度调整通知','上班制度调整通知','2018','1');
insert into `qili_bulletin`(`id`,`title`,`content`,`time`,`user_id`) values('55','春节放假通知','春节放假通知','0','1');
insert into `qili_bulletin`(`id`,`title`,`content`,`time`,`user_id`) values('58','d','ddd','1540180865','1');
