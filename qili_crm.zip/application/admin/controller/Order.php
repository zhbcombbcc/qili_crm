<?php
// +----------------------------------------------------------------------
// | snake
// +----------------------------------------------------------------------
// | Copyright (c) 2016~2022 http://baiyf.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: NickBai <1902822973@qq.com>
// +----------------------------------------------------------------------
namespace app\admin\controller;

use app\admin\model\OrderModel;
use think\Db;

class Order extends Base
{

    // 项目回款列表
    public function index()
    {
        if(request()->isAjax()){
            $param = input('param.');
            $limit = $param['pageSize'];
            $offset = ($param['pageNumber'] - 1) * $limit;
            $where = [];
            $whereTime = [];
            $whereStatus = [];
            if (!empty($param['status'])) {
                switch ($param['status']) {
                    case 1:
                        $whereStatus['status'] = ['EQ',1];
                        break;
                    case 2:
                        $whereStatus['status'] = ['EQ',2];
                        break;
                    case 3:
                        $whereStatus['is_refund'] = ['EQ',1];
                        break;
                }
            }
            if (!empty($param['start']) && !empty($param['end'])) {
                $whereTime['add_time'] = ['between time', [$param['start'], $param['end']]];
            }
            if (!empty($param['searchText'])) {
                $where['third_order_id'] = ['EQ',$param['searchText']];
            }
            $order = new OrderModel();
            $result = $order->getByWhere($where, $whereTime, $whereStatus, [], $offset, $limit);
            foreach($result as $key=>$vo){
                $result[$key]['add_time'] = date("Y-m-d",$vo['add_time']);
                $result[$key]['already_return_money'] = $vo['first_batch_backamount'] + $vo['second_batch_backamount'] + $vo['third_batch_backamount'];
                $result[$key]['remainder'] = $result[$key]['total_amount'] - $result[$key]['already_return_money'];
                $result[$key]['reminding_time'] = $vo['reminding_time'] == 0 ? "未设置" : date("Y-m-d H:i:s",$vo['reminding_time']);
                $result[$key]['operate'] = showOperate($this->makeButton($vo['id']));
            }
            $return['total'] = $order->getAll($where, $whereTime, $whereStatus, []);  // 总数据
            $return['rows'] = $result;
            return json($return);
        }
        return $this->fetch();
    }

    // 项目续费列表
    public function renew()
    {
        if(request()->isAjax()){
            $param = input('param.');
            $limit = $param['pageSize'];
            $offset = ($param['pageNumber'] - 1) * $limit;
            $whereIsExpire = [];
            $whereIsRenew = [];
            $whereSearchText = [];
            $whereTime = [];
            if (!empty($param['is_expire'])) {
                switch ($param['is_expire']) {
                    case 1:
                        $whereIsExpire['expiry_time'] = ['>',time()];
                        break;
                    case 2:
                        $whereIsExpire['expiry_time'] = ['<=',time()];
                        break;
                }
            }
            if (!empty($param['is_renew'])) {
                switch ($param['is_renew']) {
                    case 1:
                        $whereIsRenew['is_renew'] = ['=', 1];
                        break;
                    case 2:
                        $whereIsRenew['is_renew'] = ['=', 2];
                        break;
                }
            }
            if (!empty($param['start']) && !empty($param['end'])) {
                $whereTime['add_time'] = ['between time', [$param['start'], $param['end']]];
            }
            if (!empty($param['searchText'])) {
                $whereSearchText['third_order_id'] = ['EQ',$param['searchText']];
            }
            $order = new OrderModel();
            $result = $order->getByWhere($whereIsExpire, $whereIsRenew, $whereTime, $whereSearchText, $offset, $limit);
            foreach($result as $key=>$vo){
                $result[$key]['renew_time'] = $vo['renew_time'] == 0 ? "-" : date("Y-m-d",$vo['renew_time']);
                $result[$key]['expiry_time'] = $vo['expiry_time'] == 0 ? "-" : date("Y-m-d",$vo['expiry_time']);
                switch ($vo['renew_reminding']) {
                    case 1:
                        $result[$key]['renew_reminding'] = "到期前一周";
                        break;
                    case 2:
                        $result[$key]['renew_reminding'] = "到期前二周";
                        break;
                    case 3:
                        $result[$key]['renew_reminding'] = "到期前三周";
                        break;
                    case 4:
                        $result[$key]['renew_reminding'] = "到期前一月";
                        break;
                    case 5:
                        $result[$key]['renew_reminding'] = "到期前三月";
                        break;
                    default:
                        $result[$key]['renew_reminding'] = "未设置";
                        break;
                }
                $result[$key]['operate'] = showOperate($this->makeButtonSet($vo['id']));
            }
            $return['total'] = $order->getAll($whereIsExpire, $whereIsRenew, $whereTime, $whereSearchText);  // 总数据
            $return['rows'] = $result;
            return json($return);
        }
        return $this->fetch();
    }

    // 添加项目
    public function add()
    {
        if(request()->isPost()){
            $param = input('post.');
            unset($param['file']);
            $param['add_time'] = time();
            $param['first_batch_backtime'] = strtotime($param['first_batch_backtime']);
            $param['second_batch_backtime'] = strtotime($param['second_batch_backtime']);
            $param['third_batch_backtime'] = strtotime($param['third_batch_backtime']);
            $param['reminding_time'] = strtotime($param['reminding_time']);
            $param['refund_time'] = strtotime($param['refund_time']);
            $document = new OrderModel();
            $flag = $document->add($param);
            return json(msg($flag['code'], $flag['data'], $flag['msg']));
        }

        return $this->fetch();
    }

    // 编辑项目
    public function edit()
    {
        $order= new OrderModel();
        if(request()->isPost()){
            $param = input('post.');
            unset($param['file']);
            $param['first_batch_backtime'] = strtotime($param['first_batch_backtime']);
            $param['second_batch_backtime'] = strtotime($param['second_batch_backtime']);
            $param['third_batch_backtime'] = strtotime($param['third_batch_backtime']);
            $param['reminding_time'] = strtotime($param['reminding_time']);
            $param['refund_time'] = strtotime($param['refund_time']);
            $flag = $order->edit($param);
            return json(msg($flag['code'], $flag['data'], $flag['msg']));
        }

        $id = input('param.id');
        $order = $order->getOne($id);
        $order['add_time'] = date("Y-m-d H:i:s",$order['add_time']);
        $order['first_batch_backtime'] = $order['first_batch_backtime'] ? date("Y-m-d",$order['first_batch_backtime']) : '';
        $order['second_batch_backtime'] = $order['second_batch_backtime'] ? date("Y-m-d",$order['second_batch_backtime']) : '';
        $order['third_batch_backtime'] = $order['third_batch_backtime'] ? date("Y-m-d",$order['third_batch_backtime']) : '';
        $order['reminding_time'] = $order['reminding_time'] ? date("Y-m-d",$order['reminding_time']) : '';
        $order['refund_time'] = $order['refund_time'] ? date("Y-m-d",$order['refund_time']) : '';
        $this->assign([
            'order' => $order
        ]);
        return $this->fetch();
    }

    // 上传缩略图
    public function uploadImg()
    {
        if(request()->isAjax()){

            $file = request()->file('file');
            // 移动到框架应用根目录/public/uploads/ 目录下
            $info = $file->move(ROOT_PATH . 'public' . DS . 'upload');
            if($info){
                $src =  '/upload' . '/' . date('Ymd') . '/' . $info->getFilename();
                return json(msg(0, ['src' => $src], ''));
            }else{
                // 上传失败获取错误信息
                return json(msg(-1, '', $file->getError()));
            }
        }
    }

    // 删除项目
    public function del()
    {
        $id = input('param.id');
        $customer_evaluation = Db::name('order')->where('id', $id)->value('customer_evaluation');
        $order = new OrderModel();
        $flag = $order->del($id);
        if($flag){
            @unlink('./upload/'.$customer_evaluation);
        }
        return json(msg($flag['code'], $flag['data'], $flag['msg']));
    }

    /**
     * 拼装操作按钮
     * @param $id
     * @return array
     */
    private function makeButton($id)
    {
        return [
            '编辑' => [
                'auth' => 'order/edit',
                'href' => url('order/edit', ['id' => $id]),
                'btnStyle' => 'primary',
                'icon' => 'fa fa-paste'
            ],
            '删除' => [
                'auth' => 'order/del',
                'href' => "javascript:del(" . $id . ")",
                'btnStyle' => 'danger',
                'icon' => 'fa fa-trash-o'
            ],

        ];
    }

    /**
     * 拼装设置操作按钮
     * @param $id
     * @return array
     */
    private function makeButtonSet($id)
    {
        return [
            '续费设置' => [
                'auth' => 'order/set_renew',
                'href' => url('order/set_renew', ['id' => $id]),
                'btnStyle' => 'primary',
                'icon' => 'fa fa-paste'
            ],

        ];
    }

     // 续费设置
    public function set_renew()
    {
        $order= new OrderModel();
        if(request()->isPost()){
            $param = input('post.');
            $param['renew_time'] = strtotime($param['renew_time']);
            $param['expiry_time'] = strtotime($param['expiry_time']);
            $flag = $order->set_renew($param);
            return json(msg($flag['code'], $flag['data'], $flag['msg']));
        }
        $id = input('param.id');
        $order = $order->getOne($id);
        $order['renew_time'] = $order['renew_time'] ? date("Y-m-d",$order['renew_time']) : '';
        $order['expiry_time'] = $order['expiry_time'] ? date("Y-m-d",$order['expiry_time']) : '';
        $this->assign([
            'order' => $order
        ]);
        return $this->fetch();
    }

}
