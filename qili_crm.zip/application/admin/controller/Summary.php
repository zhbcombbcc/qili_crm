<?php
// +----------------------------------------------------------------------
// | snake
// +----------------------------------------------------------------------
// | Copyright (c) 2016~2022 http://baiyf.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: NickBai <1902822973@qq.com>
// +----------------------------------------------------------------------
namespace app\admin\controller;
use app\admin\model\SummaryModel;
use think\Db;
class Summary extends Base
{
    // 文章列表
    public function my()
    {
        if(request()->isAjax()){
            $param = input('param.');
            $limit = $param['pageSize'];
            $offset = ($param['pageNumber'] - 1) * $limit;
            $where1 = [];
            $where2['user_id'] = ['EQ', session('id')];
            $where3 = [];
            if (!empty($param['searchText'])) {
                $where1['title'] = ['like', '%' . $param['searchText'] . '%'];
            }
            $summary = new SummaryModel();
            $selectResult = $summary->getSummariesByWhere($where1, $where2, $where3, $offset, $limit);
            // $return['sql'] = $summary->getLastSql();
            foreach($selectResult as $key=>$vo){
                $selectResult[$key]['user_name'] = Db::name('user')->where('id',$vo['user_id'])->value('user_name');
                $selectResult[$key]['create_time'] = date("Y-m-d H:i:s",$vo['create_time']);
                $selectResult[$key]['update_time'] = $vo['update_time']==0 ? '-' : date("Y-m-d H:i:s",$vo['update_time']);
                $selectResult[$key]['operate'] = showOperate($this->makeButton($vo['id']));
            }
            $return['total'] = $summary->getAllSummaries($where1, $where2, $where3);  // 总数据
            $return['rows'] = $selectResult;
            return json($return);
        }
        return $this->fetch();
    }

     // 写总结
    public function add()
    {
        if(request()->isPost()){
            $param = input('post.');
            $param['create_time'] = time();
            $param['user_id'] = session('id');
            $summary = new SummaryModel();
            $flag = $summary->addSummary($param);
            return json(msg($flag['code'], $flag['data'], $flag['msg']));
        }
        return $this->fetch();
    }

    // 查看
    public function see(){
        $summary = Db::name('summary')->find(input('id'));
        $summary['real_name'] = Db::name('user')->where('id', $summary['user_id'])->value('real_name');
        $this->assign([
            'summary' => $summary
        ]);
        return $this->fetch();
    }

    // 修改文章
    public function edit()
    {
        $summary = new SummaryModel();
        if(request()->isPost()){
            $param = input('post.');
            $param['update_time'] = time();
            $flag = $summary->edit($param);
            return json(msg($flag['code'], $flag['data'], $flag['msg']));
        }
        $id = input('param.id');
        $this->assign([
            'summary' => $summary->getOneSummary($id)
        ]);
        return $this->fetch();
    }

    // 删除文章
    public function del()
    {
        $id = input('param.id');

        $summary = new SummaryModel();
        $flag = $summary->del($id);
        return json(msg($flag['code'], $flag['data'], $flag['msg']));
    }

    // 团队总结
    public function team(){
        if(request()->isAjax()){
            $param = input('param.');
            $limit = $param['pageSize'];
            $offset = ($param['pageNumber'] - 1) * $limit;
            $where1 = [];
            $where2 = [];
            $where3 = [];
            if(session('role_name') == '济南业务组长'){
                $jinan_ids = Db::name('user')->where('address', '济南')->column('id');
                $where2['user_id'] = ['in', $jinan_ids];
            }else if(session('role_name') == '北京业务组长'){
                $beijing_ids = Db::name('user')->where('address', '北京')->column('id');
                $where2['user_id'] = ['in', $beijing_ids];
            }
            if (!empty($param['searchText'])) {
                $where1['title'] = ['like', '%' . $param['searchText'] . '%'];
            }
            $summary = new SummaryModel();
            $selectResult = $summary->getSummariesByWhere($where1, $where2, $where3, $offset, $limit);
            foreach($selectResult as $key=>$vo){
                $selectResult[$key]['operate'] = showOperate($this->makeButton_tuandui($vo['id']));
                $selectResult[$key]['user_name'] = Db::name('user')->where('id',$vo['user_id'])->value('user_name');
                $selectResult[$key]['create_time'] = date("Y-m-d H:i:s",$vo['create_time']);
                $selectResult[$key]['update_time'] = $vo['update_time']==0 ? '-' : date("Y-m-d H:i:s",$vo['update_time']);
            }
            $return['total'] = $summary->getAllSummaries($where1, $where2, $where3);  // 总数据
            $return['rows'] = $selectResult;
            $return['role_name'] = session('role_name');
            // echo session('role_name');
            return json($return);
        }
        return $this->fetch();
    }

    /**
     * 拼装操作按钮
     * @param $id
     * @return array
     */
    private function makeButton($id)
    {
        return [
            '查看' => [
                'auth' => 'summary/see',
                'href' => url('summary/see', ['id' => $id]),
                'btnStyle' => 'primary',
                'icon' => 'fa fa-file-text-o'
            ],
            '编辑' => [
                'auth' => 'summary/edit',
                'href' => url('summary/edit', ['id' => $id]),
                'btnStyle' => 'primary',
                'icon' => 'fa fa-paste'
            ],
            '删除' => [
                'auth' => 'summary/del',
                'href' => "javascript:del(" . $id . ")",
                'btnStyle' => 'danger',
                'icon' => 'fa fa-trash-o'
            ]
        ];
    }

    /**
     * 拼装操作按钮
     * @param $id
     * @return array
     */
    private function makeButton_tuandui($id)
    {
        return [
            '查看' => [
                'auth' => 'summary/see',
                'href' => url('summary/see', ['id' => $id]),
                'btnStyle' => 'primary',
                'icon' => 'fa fa-file-text-o'
            ],
        ];
    }
}
