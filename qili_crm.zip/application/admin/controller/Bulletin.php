<?php
// +----------------------------------------------------------------------
// | snake
// +----------------------------------------------------------------------
// | Copyright (c) 2016~2022 http://baiyf.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: NickBai <1902822973@qq.com>
// +----------------------------------------------------------------------
namespace app\admin\controller;

use app\admin\model\BulletinModel;
use think\Db;

class Bulletin extends Base
{
    // 文章列表
    public function index()
    {
        if(request()->isAjax()){
            $param = input('param.');
            $limit = $param['pageSize'];
            $offset = ($param['pageNumber'] - 1) * $limit;
            $where = [];
            if (!empty($param['searchText'])) {
                $where['title'] = ['like', '%' . $param['searchText'] . '%'];
            }
            $bulletin = new BulletinModel();
            $selectResult = $bulletin->getBulletinByWhere($where, $offset, $limit);
            foreach($selectResult as $key=>$vo){
                $selectResult[$key]['time'] = date("Y-m-d H:i:s",$vo['time']);
                $selectResult[$key]['operate'] = showOperate($this->makeButton($vo['id']));
            }
            $return['total'] = $bulletin->getAllBulletin($where);  // 总数据
            $return['rows'] = $selectResult;
            return json($return);
        }
        return $this->fetch();
    }

    // 添加文章
    public function add()
    {
        if(request()->isPost()){
            $param = input('post.');
            unset($param['file']);
            $param['time'] = time();
            $param['user_id'] = session('id');
            $bulletin = new BulletinModel();
            $flag = $bulletin->add($param);
            return json(msg($flag['code'], $flag['data'], $flag['msg']));
        }

        return $this->fetch();
    }

    // 编辑
    public function edit()
    {
        $bulletin = new BulletinModel();
        if(request()->isPost()){
            $param = input('post.');
            unset($param['file']);
            $flag = $bulletin->edit($param);
            return json(msg($flag['code'], $flag['data'], $flag['msg']));
        }
        $id = input('param.id');
        $this->assign([
            'bulletin' => $bulletin->getOneBulletin($id)
        ]);
        return $this->fetch();
    }

    // 删除
    public function del()
    {
        $id = input('param.id');
        $bulletin = new BulletinModel();
        $flag = $bulletin->del($id);
        return json(msg($flag['code'], $flag['data'], $flag['msg']));
    }

    // 查看公告
    public function see(){
        $bulletin = Db::name('bulletin')->find(input('id'));
        $bulletin['real_name'] = Db::name('user')->where('id', $bulletin['user_id'])->value('real_name');
        $this->assign([
            'bulletin' => $bulletin
        ]);
        return $this->fetch();
    }
    
    /**
     * 拼装操作按钮
     * @param $id
     * @return array
     */
    private function makeButton($id)
    {
        return [
            '查看' => [
                'auth' => 'bulletin/see',
                'href' => url('bulletin/see', ['id' => $id]),
                'btnStyle' => 'primary',
                'icon' => 'fa fa-file-text-o'
            ],
            '编辑' => [
                'auth' => 'bulletin/edit',
                'href' => url('bulletin/edit', ['id' => $id]),
                'btnStyle' => 'primary',
                'icon' => 'fa fa-paste'
            ],
            '删除' => [
                'auth' => 'bulletin/del',
                'href' => "javascript:del(" . $id . ")",
                'btnStyle' => 'danger',
                'icon' => 'fa fa-trash-o'
            ],

        ];
    }

}
