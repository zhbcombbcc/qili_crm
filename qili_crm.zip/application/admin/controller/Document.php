<?php
// +----------------------------------------------------------------------
// | snake
// +----------------------------------------------------------------------
// | Copyright (c) 2016~2022 http://baiyf.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: NickBai <1902822973@qq.com>
// +----------------------------------------------------------------------
namespace app\admin\controller;

use app\admin\model\DocumentModel;
use think\Db;

class Document extends Base
{
    // 文章列表
    public function index()
    {
        if(request()->isAjax()){
            $param = input('param.');
            $limit = $param['pageSize'];
            $offset = ($param['pageNumber'] - 1) * $limit;
            $where = [];
            if (!empty($param['searchText'])) {
                $where['title'] = ['like', '%' . $param['searchText'] . '%'];
            }
            $document = new DocumentModel();
            $selectResult = $document->getDocumentByWhere($where, $offset, $limit);
            foreach($selectResult as $key=>$vo){
                $selectResult[$key]['upload_time'] = date("Y-m-d H:i:s",$vo['upload_time']);
                $selectResult[$key]['down_count'] = $vo['down_count'] . ' 次';
                $selectResult[$key]['real_name'] = Db::name('user')->where('id', $vo['user_id'])->value('real_name');
                $selectResult[$key]['operate'] = showOperate($this->makeButton($vo['id']));
            }
            $return['total'] = $document->getAllDocument($where);  // 总数据
            $return['rows'] = $selectResult;
            return json($return);
        }
        return $this->fetch();
    }

    // 添加文章
    public function add()
    {
        if(request()->isPost()){
            $param = input('post.');
            unset($param['file']);
            $param['upload_time'] = time();
            $param['user_id'] = session('id');
            $document = new DocumentModel();
            $flag = $document->add($param);
            return json(msg($flag['code'], $flag['data'], $flag['msg']));
        }

        return $this->fetch();
    }

    // 文件异步上传
    public function upload(){
        $file = request()->file(input('name'));
        $data['title'] = $file -> getInfo()['name'];

        $info = $file->move(ROOT_PATH . 'public/upload');

        if($info){
            $data['fileName'] = str_replace('\\', '/', $info->getSaveName());
            return json_encode($data); //文件名
        }
    }

    // 文件下载
    public function download(){
        if(request()->isAjax()){
            $id = input('param.id');
            $doc_path = Db::name('document')->where('id', $id)->value('doc_path');
            if(file_exists('./upload/' . $doc_path)){
                Db::name('document')->where('id', $id)->setInc('down_count');
                return json(msg(1, '/upload/' . $doc_path, "下载成功"));
            }else{
                return json(msg(-1, '', "源文件不存在"));
            }
        }
    }

    // 删除
    public function del()
    {
        $id = input('param.id');
        $doc_path = Db::name('document')->where('id', $id)->value('doc_path');
        $document = new DocumentModel();
        $flag = $document->del($id);
        if($flag){
            @unlink('./upload/'.$doc_path);
        }
        return json(msg($flag['code'], $flag['data'], $flag['msg']));
    }

    /**
     * 拼装操作按钮
     * @param $id
     * @return array
     */
    private function makeButton($id)
    {
        return [
            '下载' => [
                'auth' => 'document/download',
                // 'href' => url('document/download', ['id' => $id]),
                'href' => "javascript:download(" . $id . ")",
                'btnStyle' => 'primary',
                'icon' => 'fa fa-paste'
            ],
            '删除' => [
                'auth' => 'document/del',
                'href' => "javascript:del(" . $id . ")",
                'btnStyle' => 'danger',
                'icon' => 'fa fa-trash-o'
            ],

        ];
    }

}
