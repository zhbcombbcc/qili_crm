<?php
// +----------------------------------------------------------------------
// | snake
// +----------------------------------------------------------------------
// | Copyright (c) 2016~2022 http://baiyf.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: NickBai <1902822973@qq.com>
// +----------------------------------------------------------------------
namespace app\admin\controller;

use app\admin\model\CustomerModel;
use think\Db;

class Customer extends Base
{

    // 项目回款列表
    public function index()
    {
        if(request()->isAjax()){
            $param = input('param.');
            $limit = $param['pageSize'];
            $offset = ($param['pageNumber'] - 1) * $limit;
            $where = [];
            $whereTime = [];
            $whereStatus = [];
            $whereSource = [];
            if (!empty($param['searchType']) && !empty($param['searchText'])) {
                $where[$param['searchType']] = ['like', '%' . $param['searchText'] . '%'];
            }
            if (!empty($param['status'])) {
                $whereStatus['status'] = ['EQ',$param['status']];
            }
            if (!empty($param['source'])) {
                $whereSource['source'] = ['EQ',$param['source']];
            }
            if (!empty($param['start']) && !empty($param['end'])) {
                $whereTime['add_time'] = ['between time', [$param['start'], $param['end']]];
            }

            

            $customer = new CustomerModel();
            $result = $customer->getByWhere($where, $whereTime, $whereStatus, $whereSource, $offset, $limit);
            foreach($result as $key=>$vo){
                $result[$key]['add_time'] = date("Y-m-d",$vo['add_time']);
                switch ($vo['source']) {
                    case 1:
                        $result[$key]['source'] = '猪八戒网';
                        break;
                    case 2:
                        $result[$key]['source'] = '威客网';
                        break;
                    case 3:
                        $result[$key]['source'] = '老客户';
                        break;
                    case 4:
                        $result[$key]['source'] = '其他';
                        break;
                }
                switch ($vo['status']) {
                    case 1:
                        $result[$key]['status'] = '可跟';
                        break;
                    case 2:
                        $result[$key]['status'] = '潜在';
                        break;
                    case 3:
                        $result[$key]['status'] = '意向';
                        break;
                    case 4:
                        $result[$key]['status'] = '成交';
                        break;
                    case 5:
                        $result[$key]['status'] = '退款';
                        break;
                    case 6:
                        $result[$key]['status'] = 'OUT';
                        break;
                }
                $result[$key]['operate'] = showOperate($this->makeButton($vo['id']));
            }
            $return['total'] = $customer->getAll($where, $whereTime, $whereStatus, $whereSource);  // 总数据
            $return['rows'] = $result;
            return json($return);
        }
        return $this->fetch();
    }

    // 添加项目
    public function add()
    {
        if(request()->isPost()){
            $param = input('post.');
            unset($param['file']);
            $param['add_time'] = time();
            $customer = new CustomerModel();
            $flag = $customer->add($param);
            return json(msg($flag['code'], $flag['data'], $flag['msg']));
        }
        return $this->fetch();
    }

    // 基本资料
    public function edit()
    {
        $customer= new CustomerModel();
        if(request()->isPost()){
            $param = input('post.');
            unset($param['file']);
            $flag = $customer->edit($param);
            return json(msg($flag['code'], $flag['data'], $flag['msg']));
        }

        $id = input('param.id');
        $customer = $customer->getOne($id);
        $this->assign([
            'customer' => $customer
        ]);
        return $this->fetch();
    }    

    // 状态跟进
    public function track()
    {
        $customer= new CustomerModel();
        if(request()->isPost()){
            $param = input('post.');
            unset($param['file']);
            $param['one_time']=strtotime($param['one_time']);
            $param['two_time']=strtotime($param['two_time']);
            $param['three_time']=strtotime($param['three_time']);
            $flag = $customer->edit($param);
            return json(msg($flag['code'], $flag['data'], $flag['msg']));
        }
        $id = input('param.id');
        $customer = $customer->getOne($id);
        $customer['one_time'] = $customer['one_time'] ? date("Y-m-d",$customer['one_time']) : '';
        $customer['two_time'] = $customer['two_time'] ? date("Y-m-d",$customer['two_time']) : '';
        $customer['three_time'] = $customer['three_time'] ? date("Y-m-d",$customer['three_time']) : '';
        $this->assign([
            'customer' => $customer
        ]);
        return $this->fetch();
    }

    // 成交信息填写
    public function deal()
    {
        $customer= new CustomerModel();
        if(request()->isPost()){
            $param = input('post.');
            unset($param['file']);
            $flag = $customer->edit($param);
            return json(msg($flag['code'], $flag['data'], $flag['msg']));
        }
        $id = input('param.id');
        $customer = $customer->getOne($id);
        $order = Db::name('order')->where('customer_id', $customer['id'])->find();
        // $customer['order']
        // dump($customer['order']);
        $order['start_time'] = $order['start_time'] ? date("Y-m-d",$order['start_time']) : '';
        $order['end_time'] = $order['end_time'] ? date("Y-m-d",$order['end_time']) : '';
        $customer['order'] = $order;
        // dump($customer);
        $this->assign([
            'customer' => $customer
        ]);
        return $this->fetch();
    }

    // 文件异步上传
    public function upload(){
        $file = request()->file(input('name'));
        $data['title'] = $file -> getInfo()['name'];

        $info = $file->move(ROOT_PATH . 'public/upload');

        if($info){
            $data['fileName'] = str_replace('\\', '/', $info->getSaveName());
            return json_encode($data); //文件名
        }
    }

    // 上传缩略图
    public function uploadImg()
    {
        if(request()->isAjax()){

            $file = request()->file('file');
            // 移动到框架应用根目录/public/uploads/ 目录下
            $info = $file->move(ROOT_PATH . 'public' . DS . 'upload');
            if($info){
                $src =  '/upload' . '/' . date('Ymd') . '/' . $info->getFilename();
                return json(msg(0, ['src' => $src], ''));
            }else{
                // 上传失败获取错误信息
                return json(msg(-1, '', $file->getError()));
            }
        }
    }

    // 删除项目
    public function del()
    {
        $id = input('param.id');
        $demand_file_path = Db::name('customer')->where('id', $id)->value('demand_file_path');
        $remarks_file_path = Db::name('customer')->where('id', $id)->value('remarks_file_path');
        $customer = new CustomerModel();
        $flag = $customer->del($id);
        if($flag){
            @unlink('./upload/'.$demand_file_path);
            @unlink('./upload/'.$remarks_file_path);
        }
        return json(msg($flag['code'], $flag['data'], $flag['msg']));
    }

    /**
     * 拼装操作按钮
     * @param $id
     * @return array
     */
    private function makeButton($id)
    {
        return [
            '基本资料' => [
                'auth' => 'customer/edit',
                'href' => url('customer/edit', ['id' => $id]),
                'btnStyle' => 'primary',
                'icon' => 'fa fa-paste'
            ],
            '状态跟进' => [
                'auth' => 'customer/track',
                'href' => url('customer/track', ['id' => $id]),
                'btnStyle' => 'primary',
                'icon' => 'fa fa-spin fa-spinner'
            ],
            '成交填写' => [
                'auth' => 'customer/deal',
                'href' => url('customer/deal', ['id' => $id]),
                'btnStyle' => 'primary',
                'icon' => 'fa fa-spin fa-gavel'
            ],

            '删除' => [
                'auth' => 'customer/del',
                'href' => "javascript:del(" . $id . ")",
                'btnStyle' => 'danger',
                'icon' => 'fa fa-trash-o'
            ],

        ];
    }
 
}
