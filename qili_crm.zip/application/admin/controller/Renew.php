<?php
// +----------------------------------------------------------------------
// | snake
// +----------------------------------------------------------------------
// | Copyright (c) 2016~2022 http://baiyf.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: NickBai <1902822973@qq.com>
// +----------------------------------------------------------------------
namespace app\admin\controller;

use app\admin\model\RenewModel;
use think\Db;

class Renew extends Base
{
    // 文章列表
    public function index()
    {
        if(request()->isAjax()){
            $param = input('param.');
            $limit = $param['pageSize'];
            $offset = ($param['pageNumber'] - 1) * $limit;
            $where = [];
            $whereTime = [];
            $whereStatus = [];
            // if (!empty($param['status'])) {
            //     switch ($param['status']) {
            //         case 1:
            //             $whereStatus['status'] = ['EQ',1];
            //             break;
            //         case 2:
            //             $whereStatus['status'] = ['EQ',2];
            //             break;
            //         case 3:
            //             $whereStatus['is_refund'] = ['EQ',1];
            //             break;
            //     }
            // }
            // if (!empty($param['start']) && !empty($param['end'])) {
            //     $whereTime['add_time'] = ['between time', [$param['start'], $param['end']]];
            // }
            // if (!empty($param['searchText'])) {
            //     $where['order_id'] = ['EQ',$param['searchText']];
            // }
            $renew = new RenewModel();
            $result = $renew->getByWhere($where, $whereTime, $whereStatus, $offset, $limit);
            foreach($result as $key=>$vo){
                $result[$key]['renew_time'] = date("Y-m-d",$vo['renew_time']);
                $result[$key]['expiry_time'] = date("Y-m-d",$vo['expiry_time']);
                $result[$key]['third_order_id'] = Db::name('order')->where('id',$vo['order_id'])->value('third_order_id');
                $result[$key]['project_name'] = Db::name('order')->where('id',$vo['order_id'])->value('project_name');
                switch ($vo['renew_reminding']) {
                    case 1:
                        $result[$key]['renew_reminding'] = "提前一周";
                        break;
                    case 2:
                        $result[$key]['renew_reminding'] = "提前二周";
                        break;
                    case 3:
                        $result[$key]['renew_reminding'] = "提前三周";
                        break;
                    case 4:
                        $result[$key]['renew_reminding'] = "提前一月";
                        break;
                    case 5:
                        $result[$key]['renew_reminding'] = "提前三月";
                        break;
                    default:
                        $result[$key]['renew_reminding'] = "未设置";
                        break;
                }
                $result[$key]['operate'] = showOperate($this->makeButton($vo['id']));
            }
            $return['total'] = $renew->getAll($where, $whereTime, $whereStatus);  // 总数据
            $return['rows'] = $result;
            return json($return);
        }
        return $this->fetch();
    }

    // 添加文章
    // public function add()
    // {
    //     if(request()->isPost()){
    //         $param = input('post.');
    //         unset($param['file']);
    //         $param['add_time'] = time();
    //         $param['first_batch_backtime'] = strtotime($param['first_batch_backtime']);
    //         $param['second_batch_backtime'] = strtotime($param['second_batch_backtime']);
    //         $param['third_batch_backtime'] = strtotime($param['third_batch_backtime']);
    //         $param['reminding_time'] = strtotime($param['reminding_time']);
    //         $param['refund_time'] = strtotime($param['refund_time']);
    //         $document = new OrderModel();
    //         $flag = $document->add($param);
    //         return json(msg($flag['code'], $flag['data'], $flag['msg']));
    //     }

    //     return $this->fetch();
    // }

    // 编辑商品
    // public function edit()
    // {
    //     $order= new OrderModel();
    //     if(request()->isPost()){
    //         $param = input('post.');
    //         unset($param['file']);
    //         $param['first_batch_backtime'] = strtotime($param['first_batch_backtime']);
    //         $param['second_batch_backtime'] = strtotime($param['second_batch_backtime']);
    //         $param['third_batch_backtime'] = strtotime($param['third_batch_backtime']);
    //         $param['reminding_time'] = strtotime($param['reminding_time']);
    //         $param['refund_time'] = strtotime($param['refund_time']);
    //         $flag = $order->edit($param);
    //         return json(msg($flag['code'], $flag['data'], $flag['msg']));
    //     }

    //     $id = input('param.id');
    //     $order = $order->getOneOrder($id);
    //     $order['add_time'] = date("Y-m-d H:i:s",$order['add_time']);
    //     $order['first_batch_backtime'] = $order['first_batch_backtime'] ? date("Y-m-d",$order['first_batch_backtime']) : '';
    //     $order['second_batch_backtime'] = $order['second_batch_backtime'] ? date("Y-m-d",$order['second_batch_backtime']) : '';
    //     $order['third_batch_backtime'] = $order['third_batch_backtime'] ? date("Y-m-d",$order['third_batch_backtime']) : '';
    //     $order['reminding_time'] = $order['reminding_time'] ? date("Y-m-d",$order['reminding_time']) : '';
    //     $order['refund_time'] = $order['refund_time'] ? date("Y-m-d",$order['refund_time']) : '';
    //     $this->assign([
    //         'order' => $order
    //     ]);
    //     return $this->fetch();
    // }


    // // 文件异步上传
    // public function upload(){
    //     $file = request()->file(input('name'));
    //     $data['title'] = $file -> getInfo()['name'];

    //     $info = $file->move(ROOT_PATH . 'public/upload');

    //     if($info){
    //         $data['fileName'] = str_replace('\\', '/', $info->getSaveName());
    //         return json_encode($data); //文件名
    //     }
    // }

    // 上传缩略图
    // public function uploadImg()
    // {
    //     if(request()->isAjax()){

    //         $file = request()->file('file');
    //         // 移动到框架应用根目录/public/uploads/ 目录下
    //         $info = $file->move(ROOT_PATH . 'public' . DS . 'upload');
    //         if($info){
    //             $src =  '/upload' . '/' . date('Ymd') . '/' . $info->getFilename();
    //             return json(msg(0, ['src' => $src], ''));
    //         }else{
    //             // 上传失败获取错误信息
    //             return json(msg(-1, '', $file->getError()));
    //         }
    //     }
    // }


    // 文件下载
    // public function download(){
    //     if(request()->isAjax()){
    //         $id = input('param.id');
    //         $doc_path = Db::name('document')->where('id', $id)->value('doc_path');
    //         if(file_exists('./upload/' . $doc_path)){
    //             Db::name('document')->where('id', $id)->setInc('down_count');
    //             return json(msg(1, '/upload/' . $doc_path, "下载成功"));
    //         }else{
    //             return json(msg(-1, '', "源文件不存在"));
    //         }
    //     }
    // }

    // 删除
    // public function del()
    // {
    //     $id = input('param.id');
    //     $customer_evaluation = Db::name('order')->where('id', $id)->value('customer_evaluation');
    //     $order = new OrderModel();
    //     $flag = $order->del($id);
    //     if($flag){
    //         @unlink('./upload/'.$customer_evaluation);
    //     }
    //     return json(msg($flag['code'], $flag['data'], $flag['msg']));
    // }

    /**
     * 拼装操作按钮
     * @param $id
     * @return array
     */
    private function makeButton($id)
    {
        return [
            '编辑' => [
                'auth' => 'renew/edit',
                'href' => url('renew/edit', ['id' => $id]),
                'btnStyle' => 'primary',
                'icon' => 'fa fa-paste'
            ],
            '删除' => [
                'auth' => 'renew/del',
                'href' => "javascript:del(" . $id . ")",
                'btnStyle' => 'danger',
                'icon' => 'fa fa-trash-o'
            ],

        ];
    }

}
