<?php
// +----------------------------------------------------------------------
// | snake
// +----------------------------------------------------------------------
// | Copyright (c) 2016~2022 http://baiyf.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: NickBai <1902822973@qq.com>
// +----------------------------------------------------------------------
namespace app\admin\model;

use think\Model;

class OrderModel extends Model
{
    // 确定链接表名
    protected $name = 'order';

    /**
     * 查询文章
     * @param $where
     * @param $offset
     * @param $limit
     */
    public function getByWhere($where1, $where2, $where3, $where4, $offset, $limit)
    {
        return $this->where($where1)->where($where2)->where($where3)->where($where4)->limit($offset, $limit)->select();
    }

    /**
     * 根据搜索条件获取所有的文章数量
     * @param $where
     */
    public function getAll($where1, $where2, $where3, $where4)
    {
        return $this->where($where1)->where($where2)->where($where3)->where($where4)->count();
    }

    /**
     * 添加文章
     * @param $param
     */
    public function add($param)
    {
        try{
            $result = $this->validate('OrderValidate')->save($param);
            if(false === $result){
                // 验证失败 输出错误信息
                return msg(-1, '', $this->getError());
            }else{

                return msg(1, url('order/index'), '添加项目成功');
            }
        }catch (\Exception $e){
            return msg(-2, '', $e->getMessage());
        }
    }

    /**
     * 编辑文章信息
     * @param $param
     */
    public function edit($param)
    {
        try{
            $result = $this->validate('OrderValidate')->save($param, ['id' => $param['id']]);
            if(false === $result){
                // 验证失败 输出错误信息
                return msg(-1, '', $this->getError());
            }else{

                return msg(1, url('order/index'), '编辑项目成功');
            }
        }catch(\Exception $e){
            return msg(-2, '', $e->getMessage());
        }
    }

    /**
     * 编辑文章信息
     * @param $param
     */
    public function set_renew($param)
    {
        try{
            $result = $this->save($param, ['id' => $param['id']]);
            if(false === $result){
                // 验证失败 输出错误信息
                return msg(-1, '', $this->getError());
            }else{

                return msg(1, url('order/renew'), '续费设置成功');
            }
        }catch(\Exception $e){
            return msg(-2, '', $e->getMessage());
        }
    }

    /**
     * 根据文章的id 获取文章的信息
     * @param $id
     */
    public function getOne($id)
    {
        return $this->where('id', $id)->find();
    }

    /**
     * 删除文章
     * @param $id
     */
    public function del($id)
    {
        try{
            $this->where('id', $id)->delete();
            return msg(1, '', '删除项目成功');
        }catch(\Exception $e){
            return msg(-1, '', $e->getMessage());
        }
    }
}
